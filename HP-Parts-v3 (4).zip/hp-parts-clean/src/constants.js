// src/constants.js
// Single source of truth. Import C, AI_MODELS, TYPE_COLORS from here — never redeclare locally.

export const C = {
  bg:        '#0A0F1C',
  card:      '#111827',
  surface:   '#151E2E',
  border:    '#1E2D45',
  accent:    '#4A9EFF',
  accentDim: '#1A3A6B',
  text:      '#EEF2FF',
  muted:     '#6B7A99',
  success:   '#34D399',
  warning:   '#FBBF24',
  danger:    '#F87171',
};

// Part type → accent color
export const TYPE_COLORS = {
  'Toner Cartridge': '#4A9EFF',
  'Ink Cartridge':   '#4A9EFF',
  'Fuser Assembly':  '#F0883E',
  'Drum Unit':       '#A78BFA',
  'Maintenance Kit': '#34D399',
  'Roller Kit':      '#34D399',
  'Paper Tray':      '#6B7A99',
  'Other':           '#6B7A99',
};
export function typeColor(t) { return TYPE_COLORS[t] || C.muted; }

// Filter chips on home screen
export const FILTERS = [
  'All', 'Toner Cartridge', 'Fuser Assembly', 'Drum Unit', 'Maintenance Kit', 'Other',
];

// Part types for selectors
export const PART_TYPES = [
  'Toner Cartridge', 'Ink Cartridge', 'Fuser Assembly', 'Drum Unit',
  'Maintenance Kit', 'Roller Kit', 'Paper Tray', 'PC Part',
  'RAM', 'SSD', 'HDD', 'Cable', 'Adapter', 'Other',
];

// Condition options
export const CONDITIONS = ['New', 'Good', 'Fair', 'Poor', 'Defective', 'Unknown'];

// AI model registry — id must match value stored in AsyncStorage settings.aiModel
// Pricing as of Feb 25, 2026
export const AI_MODELS = {
  vision: {
    id:          'vision',
    label:       'Vision + Gemini',
    provider:    'Google (Best Value)',
    color:       '#FFB800',
    badge:       'FREE TIER',
    note:        'First 1,000 scans/month FREE · No rate limits',
    // Per-call pricing (Vision is billed per image, not per token)
    inputPrice:  0.0015,  // $0.0015/call after free tier
    outputPrice: 0.30,    // Gemini output, per 1M tokens
  },
  gemini: {
    id:          'gemini',
    label:       'Gemini 2.5 Flash Lite',
    provider:    'Google',
    color:       '#4A9EFF',
    badge:       null,
    note:        'Cheapest vision model · 15 RPM limit',
    inputPrice:  0.08,
    outputPrice: 0.30,
  },
  gpt: {
    id:          'gpt',
    label:       'GPT-4o Mini',
    provider:    'OpenAI',
    color:       '#34D399',
    badge:       null,
    note:        'Good balance of speed and accuracy',
    inputPrice:  0.15,
    outputPrice: 0.60,
  },
  claude: {
    id:          'claude',
    label:       'Claude Haiku 4.5',
    provider:    'Anthropic',
    color:       '#C57BFF',
    badge:       null,
    note:        'Best accuracy for complex labels',
    inputPrice:  1.00,
    outputPrice: 5.00,
  },
};

export const MODEL_ORDER = ['vision', 'gemini', 'gpt', 'claude'];

// Parts that are "PC supplies" vs "printer hardware" for categorized CSV export
export const PC_SUPPLY_TYPES = new Set([
  'Toner Cartridge', 'Ink Cartridge', 'Drum Unit', 'Fuser Assembly',
  'Maintenance Kit', 'Imaging Unit', 'Waste Toner Container',
  'Transfer Belt', 'Transfer Roller', 'Feed Roller', 'Pickup Roller',
  'Staple Cartridge', 'Roller Kit',
]);

export const DEFAULT_SETTINGS = {
  aiModel:   'vision',
  visionKey: '',
  geminiKey: '',
  openaiKey: '',
  claudeKey: '',
  techName:  '',
  location:  '',
};
