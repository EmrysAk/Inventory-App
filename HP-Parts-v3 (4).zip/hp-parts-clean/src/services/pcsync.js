// src/services/pcsync.js
// Android ↔ PC Wi-Fi sync over local network.

import { getPcHost, setPcHost } from './db';

function fetchWithTimeout(url, options, ms = 8000) {
  const ctrl  = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  return fetch(url, { ...options, signal: ctrl.signal })
    .finally(() => clearTimeout(timer));
}

function normalize(host) {
  return host.endsWith('/') ? host.slice(0, -1) : host;
}

export async function testConnection(host) {
  try {
    const res  = await fetchWithTimeout(`${normalize(host)}/health`, {}, 4000);
    if (!res.ok) return { ok: false, error: `HTTP ${res.status}` };
    const data = await res.json();
    return { ok: true, info: data };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

export async function pushAllToPC(parts) {
  const host = await getPcHost();
  if (!host) return { skipped: true };
  try {
    const res = await fetchWithTimeout(`${normalize(host)}/sync`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ parts }),
    }, 30000);
    return await res.json();
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

export async function pushPartToPC(part) {
  const host = await getPcHost();
  if (!host) return { skipped: true };
  try {
    const res = await fetchWithTimeout(`${normalize(host)}/parts`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(part),
    }, 6000);
    return { ok: true, data: await res.json() };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

export async function pullFromPC() {
  const host = await getPcHost();
  if (!host) return { skipped: true };
  try {
    const res  = await fetchWithTimeout(`${normalize(host)}/export`, {}, 30000);
    const data = await res.json();
    return { ok: true, parts: data.parts || [], exportedAt: data.exportedAt };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

export { getPcHost, setPcHost };
