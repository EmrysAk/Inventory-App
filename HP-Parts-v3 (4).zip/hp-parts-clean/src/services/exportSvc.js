// src/services/exportSvc.js
// CSV and PDF generation + sharing.
// Uses expo-file-system/legacy for readAsStringAsync / writeAsStringAsync.

import * as FileSystem from 'expo-file-system/legacy';
import * as Print     from 'expo-print';
import * as Sharing   from 'expo-sharing';

const CSV_HEADERS = [
  'Part Number', 'Description', 'Part Type', 'Color',
  'Quantity', 'Serial Numbers', 'Condition',
  'Compatible Printers', 'Page Yield', 'Availability',
  'Replacement Part #', 'Location', 'Notes',
  'Date Added', 'Last Seen',
];

function partToRow(p) {
  return [
    p.partNumber || '',
    p.hpDescription || p.description || '',
    p.partType  || '',
    p.color     || '',
    p.quantity,
    (p.serialNumbers   || []).join('; '),
    p.condition || '',
    (p.compatiblePrinters || []).join('; '),
    p.pageYield     || '',
    p.availability  || '',
    p.replacementPartNumber || '',
    p.location || '',
    p.notes    || '',
    p.createdAt  ? new Date(p.createdAt).toLocaleDateString()  : '',
    p.lastSeenAt ? new Date(p.lastSeenAt).toLocaleDateString() : '',
  ];
}

export function buildCSV(parts) {
  const rows = [CSV_HEADERS, ...parts.map(partToRow)];
  return rows
    .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    .join('\n');
}

export async function shareCSV(parts, filenameBase = 'HP_Parts') {
  const csv  = buildCSV(parts);
  const date = new Date().toISOString().split('T')[0];
  const path = `${FileSystem.documentDirectory}${filenameBase}_${date}.csv`;
  await FileSystem.writeAsStringAsync(path, csv, { encoding: FileSystem.EncodingType.UTF8 });
  await Sharing.shareAsync(path, { mimeType: 'text/csv', dialogTitle: `Export ${filenameBase}` });
}

export async function shareJSON(parts) {
  const json = JSON.stringify({ parts, exportedAt: new Date().toISOString() }, null, 2);
  const date = new Date().toISOString().split('T')[0];
  const path = `${FileSystem.documentDirectory}HP_Parts_${date}.json`;
  await FileSystem.writeAsStringAsync(path, json, { encoding: FileSystem.EncodingType.UTF8 });
  await Sharing.shareAsync(path, { mimeType: 'application/json', dialogTitle: 'Share HP Parts JSON' });
}

export async function sharePDF(parts, settings = {}) {
  const date       = new Date().toLocaleDateString();
  const totalUnits = parts.reduce((s, p) => s + p.quantity, 0);

  const typeGroups = {};
  parts.forEach(p => {
    const t = p.partType || 'Other';
    if (!typeGroups[t]) typeGroups[t] = { count: 0, qty: 0 };
    typeGroups[t].count++;
    typeGroups[t].qty += p.quantity;
  });

  const summaryRows = Object.entries(typeGroups).map(([type, d]) =>
    `<tr><td>${type}</td><td>${d.count}</td><td>${d.qty}</td></tr>`
  ).join('');

  const partRows = parts.map((p, i) => `
    <tr class="${i % 2 === 0 ? 'even' : ''}">
      <td class="pn">${p.partNumber || '—'}</td>
      <td>${p.hpDescription || p.description || '—'}</td>
      <td>${p.partType || '—'}</td>
      <td>${p.color || '—'}</td>
      <td class="qty">${p.quantity}</td>
      <td>${(p.serialNumbers || []).join(', ') || '—'}</td>
      <td>${(p.compatiblePrinters || []).slice(0, 2).join(', ') || '—'}</td>
      <td>${p.location || '—'}</td>
      <td>${p.condition || '—'}</td>
    </tr>`).join('');

  const html = `<!DOCTYPE html>
<html><head><meta charset="UTF-8"/>
<style>
* { box-sizing:border-box; margin:0; padding:0; }
body { font-family: -apple-system, sans-serif; font-size:11px; color:#111; }
.header { background:#003087; color:#fff; padding:20px 24px; display:flex; justify-content:space-between; }
.header h1 { font-size:22px; font-weight:700; }
.header p  { font-size:12px; opacity:.8; margin-top:4px; }
.hr  { text-align:right; font-size:11px; opacity:.85; }
.stats { display:flex; border-bottom:2px solid #003087; }
.stat { flex:1; padding:12px 16px; border-right:1px solid #e0e0e0; }
.stat:last-child { border-right:none; }
.stat-num { font-size:26px; font-weight:700; color:#003087; }
.stat-lbl { font-size:10px; text-transform:uppercase; letter-spacing:1px; color:#666; margin-top:2px; }
.section  { padding:16px 24px; }
.sec-title { font-size:12px; font-weight:700; text-transform:uppercase; color:#003087; border-bottom:1px solid #003087; padding-bottom:4px; margin-bottom:10px; }
table { width:100%; border-collapse:collapse; }
th { background:#003087; color:#fff; padding:6px 8px; text-align:left; font-size:9px; text-transform:uppercase; }
td { padding:5px 8px; border-bottom:1px solid #e8e8e8; vertical-align:top; }
tr.even td { background:#f7f9ff; }
.pn { font-family:monospace; font-weight:700; color:#003087; white-space:nowrap; }
.qty { font-weight:700; font-size:13px; text-align:center; }
.footer { border-top:1px solid #ccc; padding:10px 24px; display:flex; justify-content:space-between; color:#888; font-size:9px; }
</style></head><body>
<div class="header">
  <div><h1>HP Printer Parts Inventory</h1><p>GIT Service · Field Inventory Report</p></div>
  <div class="hr">
    Generated: ${date}
    ${settings.techName ? `<br>Technician: ${settings.techName}` : ''}
    ${settings.location ? `<br>Location: ${settings.location}` : ''}
  </div>
</div>
<div class="stats">
  <div class="stat"><div class="stat-num">${parts.length}</div><div class="stat-lbl">Part Types</div></div>
  <div class="stat"><div class="stat-num">${totalUnits}</div><div class="stat-lbl">Total Units</div></div>
  <div class="stat"><div class="stat-num">${Object.keys(typeGroups).length}</div><div class="stat-lbl">Categories</div></div>
  <div class="stat"><div class="stat-num">${parts.filter(p => p.quantity === 0).length}</div><div class="stat-lbl">Out of Stock</div></div>
</div>
<div class="section">
  <div class="sec-title">Summary by Category</div>
  <table><thead><tr><th>Part Type</th><th>Unique Parts</th><th>Total Units</th></tr></thead>
  <tbody>${summaryRows}</tbody></table>
</div>
<div class="section">
  <div class="sec-title">Full Parts List (${parts.length} items)</div>
  <table><thead><tr>
    <th>Part #</th><th>Description</th><th>Type</th><th>Color</th>
    <th>Qty</th><th>Serial #(s)</th><th>Compatible Printers</th><th>Location</th><th>Condition</th>
  </tr></thead><tbody>${partRows}</tbody></table>
</div>
<div class="footer">
  <span>HP Parts Inventory · GIT Service · Anchorage, AK</span>
  <span>${date} · ${totalUnits} units across ${parts.length} part types</span>
</div>
</body></html>`;

  const { uri } = await Print.printToFileAsync({ html, base64: false });
  const dest    = `${FileSystem.documentDirectory}HP_Parts_${new Date().toISOString().split('T')[0]}.pdf`;
  await FileSystem.moveAsync({ from: uri, to: dest });
  await Sharing.shareAsync(dest, { mimeType: 'application/pdf', dialogTitle: 'Export HP Parts PDF' });
}
