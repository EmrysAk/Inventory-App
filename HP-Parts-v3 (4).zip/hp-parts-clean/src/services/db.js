// src/services/db.js
// All AsyncStorage reads/writes. Pure data layer — no UI logic.

import AsyncStorage from '@react-native-async-storage/async-storage';
import { DEFAULT_SETTINGS } from '../constants';

const PARTS_KEY    = '@hp_parts_v3_parts';
const SETTINGS_KEY = '@hp_parts_v3_settings';
const USAGE_KEY    = '@hp_parts_v3_usage';
const SHEETS_KEY   = '@hp_parts_v3_sheets_url';
const PC_HOST_KEY  = '@hp_parts_v3_pc_host';

// ── Helpers ───────────────────────────────────────────────────────────────────

function uid() {
  return `p_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

// ── Parts ─────────────────────────────────────────────────────────────────────

export async function loadParts() {
  try {
    const raw = await AsyncStorage.getItem(PARTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

async function _saveParts(parts) {
  await AsyncStorage.setItem(PARTS_KEY, JSON.stringify(parts));
}

/**
 * Add a part. If partNumber already exists, increments quantity and merges serial numbers.
 * Returns { item, isNew }.
 */
export async function addPart(ocrData, psData, imageUri = null, qty = 1) {
  const parts    = await loadParts();
  const partNum  = ocrData?.partNumber || psData?.hpPartNumber || null;
  const normalPN = partNum?.toUpperCase().trim() || null;

  if (normalPN) {
    const existing = parts.find(p => p.partNumber?.toUpperCase().trim() === normalPN);
    if (existing) {
      existing.quantity   += qty;
      existing.lastSeenAt  = new Date().toISOString();
      if (!existing.serialNumbers) existing.serialNumbers = [];
      const sn = ocrData?.serialNumber;
      if (sn && !existing.serialNumbers.includes(sn)) existing.serialNumbers.push(sn);
      await _saveParts(parts);
      return { item: existing, isNew: false };
    }
  }

  const item = {
    id:                    uid(),
    createdAt:             new Date().toISOString(),
    lastSeenAt:            new Date().toISOString(),
    imageUri:              imageUri || null,
    quantity:              qty,
    partNumber:            partNum || null,
    serialNumbers:         ocrData?.serialNumber ? [ocrData.serialNumber] : [],
    description:           psData?.fullDescription  || ocrData?.description  || null,
    hpDescription:         psData?.fullDescription  || null,
    partType:              psData?.partType         || ocrData?.partType      || 'Other',
    color:                 psData?.color            || ocrData?.color         || null,
    pageYield:             psData?.pageYield        || ocrData?.pageYield     || null,
    condition:             ocrData?.condition       || 'Unknown',
    compatiblePrinters:    psData?.compatiblePrinters || ocrData?.compatiblePrinters || [],
    availability:          psData?.availability     || null,
    replacementPartNumber: psData?.replacementPartNumber || null,
    partSurferNotes:       psData?.notes           || null,
    rawOcrText:            ocrData?.rawText        || null,
    location:              '',
    notes:                 '',
  };

  parts.unshift(item);
  await _saveParts(parts);
  return { item, isNew: true };
}

export async function updatePart(id, updates) {
  const parts = await loadParts();
  const idx   = parts.findIndex(p => p.id === id);
  if (idx !== -1) {
    parts[idx] = { ...parts[idx], ...updates, lastSeenAt: new Date().toISOString() };
    await _saveParts(parts);
    return parts[idx];
  }
  return null;
}

export async function updateQuantity(id, newQty) {
  return updatePart(id, { quantity: Math.max(0, newQty) });
}

export async function deletePart(id) {
  const parts = await loadParts();
  await _saveParts(parts.filter(p => p.id !== id));
}

export async function getPartById(id) {
  const parts = await loadParts();
  return parts.find(p => p.id === id) || null;
}

// ── Settings ──────────────────────────────────────────────────────────────────

export async function loadSettings() {
  try {
    const raw = await AsyncStorage.getItem(SETTINGS_KEY);
    return raw ? { ...DEFAULT_SETTINGS, ...JSON.parse(raw) } : { ...DEFAULT_SETTINGS };
  } catch { return { ...DEFAULT_SETTINGS }; }
}

export async function saveSettings(s) {
  await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
}

// ── Usage stats ───────────────────────────────────────────────────────────────

export async function loadUsage() {
  try {
    const raw = await AsyncStorage.getItem(USAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch { return {}; }
}

export async function trackUsage(model, inputTokens, outputTokens, cost) {
  try {
    const usage = await loadUsage();
    if (!usage[model]) usage[model] = { calls: 0, inputTokens: 0, outputTokens: 0, cost: 0 };
    usage[model].calls        += 1;
    usage[model].inputTokens  += inputTokens;
    usage[model].outputTokens += outputTokens;
    usage[model].cost         += cost;
    await AsyncStorage.setItem(USAGE_KEY, JSON.stringify(usage));
  } catch {}
}

export async function resetUsage() {
  await AsyncStorage.removeItem(USAGE_KEY);
}

// ── Google Sheets URL ─────────────────────────────────────────────────────────

export async function getSheetsUrl() {
  return AsyncStorage.getItem(SHEETS_KEY);
}

export async function setSheetsUrl(url) {
  await AsyncStorage.setItem(SHEETS_KEY, url.trim());
}

// ── PC sync host ──────────────────────────────────────────────────────────────

export async function getPcHost() {
  return AsyncStorage.getItem(PC_HOST_KEY);
}

export async function setPcHost(url) {
  await AsyncStorage.setItem(PC_HOST_KEY, url.trim());
}
