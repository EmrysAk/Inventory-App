// src/services/ai.js
// All AI API calls. Correct Expo 54 imports. fetchWithTimeout. Exponential backoff.
//
// IMPORT RULES (verified against Expo 54 docs):
//   expo-file-system/legacy   → readAsStringAsync, EncodingType, documentDirectory
//   expo-image-manipulator    → { manipulateAsync, SaveFormat }  (named exports, v14)
//   ImageManipulator.* namespace NO LONGER EXISTS in v14

import * as FileSystem from 'expo-file-system/legacy';
import { manipulateAsync, SaveFormat } from 'expo-image-manipulator';
import { AI_MODELS } from '../constants';
import { trackUsage } from './db';

// ── Prompts ───────────────────────────────────────────────────────────────────

const SCAN_SYSTEM = 'You are an expert OCR system for HP printer parts. Read every character precisely. Return ONLY valid JSON, no markdown.';

const SCAN_PROMPT = `You are reading an HP printer part label. Extract text EXACTLY as printed.
HP part numbers mix letters AND numbers — read each character carefully.
Common formats: CE505A, CF226A, CB435A, Q7553A, RM1-8307, C8061X, CC364A, CF280A
DO NOT guess or autocorrect — copy characters exactly as they appear.

Return ONLY this JSON, no other text:
{
  "partNumber": "exact HP part number, copy every letter and digit precisely",
  "serialNumber": "S/N or serial number if visible, else null",
  "description": "full product name exactly as printed",
  "compatiblePrinters": ["printer models listed on label or packaging"],
  "partType": "one of: Toner Cartridge|Ink Cartridge|Drum Unit|Fuser Assembly|Maintenance Kit|Roller Kit|Paper Tray|PC Part|RAM|SSD|HDD|Cable|Adapter|Other",
  "color": "Black or Cyan or Magenta or Yellow or null",
  "pageYield": "page yield number if shown, else null",
  "condition": "New if sealed/boxed, Used if open, Unknown",
  "rawText": "ALL visible text from label copied verbatim"
}`;

// Vision+Gemini step 2: parse raw OCR text into structured JSON
const VISION_PARSE = (rawText) =>
`You are parsing raw OCR text extracted from an HP printer part label.
The text below was read by Google Cloud Vision — do not correct it, parse it exactly.

RAW OCR TEXT:
${rawText}

HP part numbers mix letters and numbers. Common formats: CE505A, CF226A, RM1-8307, C8061X
Copy the part number exactly as it appears in the text above.

Return ONLY this JSON:
{
  "partNumber": "HP part number exactly as found in raw text",
  "serialNumber": "S/N or serial if present, else null",
  "description": "product name or description",
  "compatiblePrinters": ["any printer models mentioned"],
  "partType": "one of: Toner Cartridge|Ink Cartridge|Drum Unit|Fuser Assembly|Maintenance Kit|Roller Kit|Paper Tray|PC Part|RAM|SSD|HDD|Cable|Adapter|Other",
  "color": "Black or Cyan or Magenta or Yellow or null",
  "pageYield": "page yield number if present, else null",
  "condition": "New if sealed/boxed, Used if open, Unknown",
  "rawText": "${rawText.replace(/"/g, "'").slice(0, 500)}"
}`;

const LOOKUP_JSON = `{
  "hpPartNumber": "official HP part number",
  "fullDescription": "complete product description",
  "compatiblePrinters": ["compatible HP printer models"],
  "partType": "part category",
  "color": "color or null",
  "pageYield": "page yield or null",
  "availability": "In Stock or Discontinued or Unknown",
  "replacementPartNumber": "newer replacement part number or null",
  "notes": "any important notes or null"
}`;

// ── Utilities ─────────────────────────────────────────────────────────────────

function fetchWithTimeout(url, options, ms = 30000) {
  const ctrl  = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  return fetch(url, { ...options, signal: ctrl.signal })
    .finally(() => clearTimeout(timer));
}

async function parseApiError(res, provider) {
  try {
    const body = await res.json();
    const msg  = body?.error?.message || body?.message || JSON.stringify(body).slice(0, 150);
    return new Error(`${provider} ${res.status}: ${msg}`);
  } catch {
    return new Error(`${provider} ${res.status}: ${res.statusText}`);
  }
}

function parseJSON(text) {
  const clean = (text || '').replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim();
  try { return JSON.parse(clean); } catch {}
  const m = clean.match(/\{[\s\S]*\}/);
  if (m) { try { return JSON.parse(m[0]); } catch {} }
  return { parseError: true, rawResponse: text?.slice(0, 200) };
}

async function withBackoff(fn, maxRetries = 3) {
  let attempt = 0;
  while (true) {
    try { return await fn(); }
    catch (err) {
      const isRate = /429|RESOURCE_EXHAUSTED|quota/i.test(err.message || '');
      if (isRate && attempt < maxRetries) {
        attempt++;
        await new Promise(r => setTimeout(r, attempt * 8000));
      } else throw err;
    }
  }
}

function calcCost(model, inputTokens, outputTokens) {
  const m = AI_MODELS[model];
  if (!m) return 0;
  if (model === 'vision') {
    // inputTokens = Vision API call count ($0.0015/call)
    // outputTokens = Gemini parse output tokens
    return (inputTokens * 0.0015) + ((outputTokens / 1_000_000) * 0.30);
  }
  return ((inputTokens  / 1_000_000) * m.inputPrice) +
         ((outputTokens / 1_000_000) * m.outputPrice);
}

// ── Image helpers (used by scan screen) ──────────────────────────────────────

/** Read any local image URI to base64 string */
export async function imageToBase64(uri) {
  return FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
}

/** Crop an image by pixel coords, return new URI */
export async function cropImage(uri, originX, originY, width, height) {
  const result = await manipulateAsync(
    uri,
    [{ crop: { originX, originY, width, height } }],
    { compress: 0.95, format: SaveFormat.JPEG }
  );
  return result.uri;
}

// ── Google Cloud Vision (step 1: pure OCR) ────────────────────────────────────

async function ocrWithVision(base64, apiKey) {
  const res = await fetchWithTimeout(
    `https://vision.googleapis.com/v1/images:annotate?key=${apiKey}`,
    {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        requests: [{
          image:    { content: base64 },
          features: [
            { type: 'TEXT_DETECTION',          maxResults: 1 },
            { type: 'DOCUMENT_TEXT_DETECTION', maxResults: 1 },
          ],
        }],
      }),
    }, 15000
  );
  if (!res.ok) throw await parseApiError(res, 'Google Vision');
  const data = await res.json();
  if (data.responses?.[0]?.error) throw new Error(`Vision: ${data.responses[0].error.message}`);
  const text = data.responses?.[0]?.fullTextAnnotation?.text
            || data.responses?.[0]?.textAnnotations?.[0]?.description
            || '';
  if (!text) throw new Error('Vision returned no text — check image quality or lighting');
  return text;
}

// ── Gemini 2.5 Flash Lite ─────────────────────────────────────────────────────

const GEMINI_URL = (key) =>
  `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=${key}`;

async function _geminiCall(apiKey, systemText, userText, timeoutMs = 25000) {
  const res = await fetchWithTimeout(GEMINI_URL(apiKey), {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      generationConfig:  { maxOutputTokens: 600, temperature: 0 },
      systemInstruction: { parts: [{ text: systemText }] },
      contents: [{ role: 'user', parts: [{ text: userText }] }],
    }),
  }, timeoutMs);
  if (!res.ok) {
    const b = await res.json().catch(() => ({}));
    throw new Error(`Gemini ${res.status}: ${b?.error?.message || res.statusText}`);
  }
  const data  = await res.json();
  const text  = data.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
  const usage = data.usageMetadata || {};
  return { text, inputTokens: usage.promptTokenCount || 0, outputTokens: usage.candidatesTokenCount || 0 };
}

async function _geminiImageCall(apiKey, base64, mimeType, userText) {
  const res = await fetchWithTimeout(GEMINI_URL(apiKey), {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      generationConfig:  { maxOutputTokens: 600, temperature: 0 },
      systemInstruction: { parts: [{ text: SCAN_SYSTEM }] },
      contents: [{ role: 'user', parts: [
        { inlineData: { mimeType, data: base64 } },
        { text: userText },
      ]}],
    }),
  }, 30000);
  if (!res.ok) {
    const b = await res.json().catch(() => ({}));
    throw new Error(`Gemini ${res.status}: ${b?.error?.message || res.statusText}`);
  }
  const data  = await res.json();
  const text  = data.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
  const usage = data.usageMetadata || {};
  return { text, inputTokens: usage.promptTokenCount || 0, outputTokens: usage.candidatesTokenCount || 0 };
}

// ── Vision + Gemini combined ──────────────────────────────────────────────────

async function scanVision(base64, mimeType, visionKey, geminiKey) {
  const rawText = await ocrWithVision(base64, visionKey);
  const parsed  = await _geminiCall(
    geminiKey,
    'You are an HP parts data parser. Return ONLY valid JSON.',
    VISION_PARSE(rawText)
  );
  return { result: parseJSON(parsed.text), inputTokens: 1, outputTokens: parsed.outputTokens };
}

async function lookupVision(partNumber, geminiKey) {
  const r = await _geminiCall(
    geminiKey,
    'You are an HP parts database expert. Return ONLY valid JSON.',
    `HP part number: ${partNumber}. Using your knowledge, return ONLY this JSON: ${LOOKUP_JSON}`
  );
  return { result: parseJSON(r.text), inputTokens: r.inputTokens, outputTokens: r.outputTokens };
}

// ── Gemini scan/lookup ────────────────────────────────────────────────────────

async function scanGemini(base64, mimeType, apiKey) {
  const r = await _geminiImageCall(apiKey, base64, mimeType, SCAN_PROMPT);
  return { result: parseJSON(r.text), inputTokens: r.inputTokens, outputTokens: r.outputTokens };
}

async function lookupGemini(partNumber, apiKey) {
  const r = await _geminiCall(
    apiKey,
    'You are an HP parts database expert. Return ONLY valid JSON.',
    `HP part number: ${partNumber}. Return ONLY this JSON: ${LOOKUP_JSON}`
  );
  return { result: parseJSON(r.text), inputTokens: r.inputTokens, outputTokens: r.outputTokens };
}

// ── Claude Haiku 4.5 ──────────────────────────────────────────────────────────

async function scanClaude(base64, mimeType, apiKey) {
  const res = await fetchWithTimeout('https://api.anthropic.com/v1/messages', {
    method:  'POST',
    headers: {
      'Content-Type':      'application/json',
      'x-api-key':         apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model:      'claude-haiku-4-5',
      max_tokens: 600,
      system:     SCAN_SYSTEM,
      messages: [{
        role:    'user',
        content: [
          { type: 'image', source: { type: 'base64', media_type: mimeType, data: base64 } },
          { type: 'text',  text:   SCAN_PROMPT },
        ],
      }],
    }),
  }, 30000);
  if (!res.ok) throw await parseApiError(res, 'Claude');
  const data  = await res.json();
  const text  = data.content?.find(b => b.type === 'text')?.text || '{}';
  const usage = data.usage || {};
  return { result: parseJSON(text), inputTokens: usage.input_tokens || 0, outputTokens: usage.output_tokens || 0 };
}

async function lookupClaude(partNumber, apiKey) {
  const res = await fetchWithTimeout('https://api.anthropic.com/v1/messages', {
    method:  'POST',
    headers: {
      'Content-Type':      'application/json',
      'x-api-key':         apiKey,
      'anthropic-version': '2023-06-01',
      'anthropic-beta':    'web-search-2025-03-05',
    },
    body: JSON.stringify({
      model:      'claude-haiku-4-5',
      max_tokens: 800,
      system:     'You are an HP parts lookup assistant. Search for the part and return ONLY valid JSON.',
      tools:      [{ type: 'web_search_20250305', name: 'web_search' }],
      messages: [{
        role:    'user',
        content: `Search HP PartSurfer for: ${partNumber}\nURL: https://partsurfer.hp.com/Search.aspx?SearchText=${encodeURIComponent(partNumber)}\n\nReturn ONLY this JSON: ${LOOKUP_JSON}`,
      }],
    }),
  }, 45000);
  if (!res.ok) throw await parseApiError(res, 'Claude');
  const data  = await res.json();
  const text  = (data.content || []).filter(b => b.type === 'text').map(b => b.text).join('');
  const usage = data.usage || {};
  return { result: parseJSON(text), inputTokens: usage.input_tokens || 0, outputTokens: usage.output_tokens || 0 };
}

// ── GPT-4o Mini ───────────────────────────────────────────────────────────────

async function scanGPT(base64, mimeType, apiKey) {
  const res = await fetchWithTimeout('https://api.openai.com/v1/chat/completions', {
    method:  'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
    body: JSON.stringify({
      model:      'gpt-4o-mini',
      max_tokens: 600,
      messages: [
        { role: 'system', content: SCAN_SYSTEM },
        { role: 'user', content: [
          { type: 'image_url', image_url: { url: `data:${mimeType};base64,${base64}`, detail: 'high' } },
          { type: 'text', text: SCAN_PROMPT },
        ]},
      ],
    }),
  }, 30000);
  if (!res.ok) throw await parseApiError(res, 'OpenAI');
  const data  = await res.json();
  const text  = data.choices?.[0]?.message?.content || '{}';
  const usage = data.usage || {};
  return { result: parseJSON(text), inputTokens: usage.prompt_tokens || 0, outputTokens: usage.completion_tokens || 0 };
}

async function lookupGPT(partNumber, apiKey) {
  const res = await fetchWithTimeout('https://api.openai.com/v1/chat/completions', {
    method:  'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
    body: JSON.stringify({
      model:      'gpt-4o-mini',
      max_tokens: 800,
      messages: [
        { role: 'system', content: 'You are an HP parts database expert. Return ONLY valid JSON, no markdown.' },
        { role: 'user',   content: `HP part number: ${partNumber}\nReturn ONLY this JSON: ${LOOKUP_JSON}` },
      ],
    }),
  }, 30000);
  if (!res.ok) throw await parseApiError(res, 'OpenAI');
  const data  = await res.json();
  const text  = data.choices?.[0]?.message?.content || '{}';
  const usage = data.usage || {};
  return { result: parseJSON(text), inputTokens: usage.prompt_tokens || 0, outputTokens: usage.completion_tokens || 0 };
}

// ── Key resolver ──────────────────────────────────────────────────────────────

function getKey(model, settings) {
  switch (model) {
    case 'vision': return settings.visionKey || '';
    case 'gemini': return settings.geminiKey || '';
    case 'gpt':    return settings.openaiKey || '';
    case 'claude': return settings.claudeKey || '';
    default:       return '';
  }
}

// ── Public API ────────────────────────────────────────────────────────────────

/**
 * Scan a label image. Returns parsed OCR data object.
 * base64: string, mimeType: 'image/jpeg', settings: from db.loadSettings()
 */
export async function scanLabel(base64, mimeType = 'image/jpeg', settings) {
  const model = settings.aiModel || 'vision';

  let res;
  if (model === 'vision') {
    const vKey = getKey('vision', settings);
    const gKey = settings.geminiKey || '';
    if (!vKey) throw new Error('No Google Cloud Vision API key. Add it in Settings.');
    if (!gKey) throw new Error('Gemini API key also required for Vision+Gemini. Add it in Settings.');
    res = await scanVision(base64, mimeType, vKey, gKey);
  } else {
    const key = getKey(model, settings);
    if (!key) throw new Error(`No API key set for ${AI_MODELS[model]?.label || model}. Add it in Settings.`);
    if (model === 'gemini') res = await withBackoff(() => scanGemini(base64, mimeType, key));
    else if (model === 'gpt') res = await withBackoff(() => scanGPT(base64, mimeType, key));
    else res = await scanClaude(base64, mimeType, key);
  }

  const cost = calcCost(model, res.inputTokens, res.outputTokens);
  await trackUsage(model, res.inputTokens, res.outputTokens, cost);
  return res.result;
}

/**
 * Look up a part number via the active AI model. Non-fatal — returns {} on failure.
 */
export async function lookupPart(partNumber, settings) {
  if (!partNumber) return {};
  const model = settings.aiModel || 'vision';
  try {
    let res;
    if (model === 'vision') {
      const gKey = settings.geminiKey || '';
      if (!gKey) return {};
      res = await withBackoff(() => lookupVision(partNumber, gKey));
    } else {
      const key = getKey(model, settings);
      if (!key) return {};
      if (model === 'gemini') res = await withBackoff(() => lookupGemini(partNumber, key));
      else if (model === 'gpt') res = await withBackoff(() => lookupGPT(partNumber, key));
      else res = await lookupClaude(partNumber, key);
    }
    const cost = calcCost(model, res.inputTokens, res.outputTokens);
    await trackUsage(model, res.inputTokens, res.outputTokens, cost);
    return res.result || {};
  } catch { return {}; }
}

// Expose cost formatter for settings screen
export function formatCost(usd) {
  const n = Number(usd);
  if (!n || isNaN(n) || n === 0) return '$0.00';
  if (n < 0.0001) return '<$0.0001';
  return `$${n.toFixed(4)}`;
}
