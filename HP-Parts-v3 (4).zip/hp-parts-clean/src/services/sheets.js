// src/services/sheets.js
// Google Sheets sync via Apps Script Web App.

import { getSheetsUrl, setSheetsUrl } from './db';

function fetchWithTimeout(url, options, ms = 30000) {
  const ctrl  = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  return fetch(url, { ...options, signal: ctrl.signal })
    .finally(() => clearTimeout(timer));
}

function flattenPart(p) {
  return {
    id:                    p.id || '',
    partNumber:            p.partNumber || '',
    description:           p.hpDescription || p.description || '',
    partType:              p.partType || 'Other',
    color:                 p.color || '',
    quantity:              p.quantity ?? 0,
    serialNumbers:         (p.serialNumbers || []).join('; '),
    compatiblePrinters:    (p.compatiblePrinters || []).join('; '),
    pageYield:             p.pageYield || '',
    condition:             p.condition || 'Unknown',
    availability:          p.availability || '',
    replacementPartNumber: p.replacementPartNumber || '',
    location:              p.location || '',
    notes:                 p.notes || '',
    createdAt:             p.createdAt || new Date().toISOString(),
    lastSeenAt:            p.lastSeenAt || new Date().toISOString(),
    source:                'mobile',
  };
}

function expandPart(row) {
  return {
    id:                    row.id,
    partNumber:            row.partNumber,
    description:           row.description,
    hpDescription:         row.description,
    partType:              row.partType || 'Other',
    color:                 row.color,
    quantity:              parseInt(row.quantity) || 0,
    serialNumbers:         row.serialNumbers ? row.serialNumbers.split('; ').filter(Boolean) : [],
    compatiblePrinters:    row.compatiblePrinters ? row.compatiblePrinters.split('; ').filter(Boolean) : [],
    pageYield:             row.pageYield,
    condition:             row.condition || 'Unknown',
    availability:          row.availability,
    replacementPartNumber: row.replacementPartNumber,
    location:              row.location,
    notes:                 row.notes,
    createdAt:             row.createdAt,
    lastSeenAt:            row.lastSeenAt,
  };
}

async function request(action, payload = {}) {
  const url = await getSheetsUrl();
  if (!url) throw new Error('Google Sheets not configured. Add your Apps Script URL in Settings.');
  const res = await fetchWithTimeout(url, {
    method:  'POST',
    headers: { 'Content-Type': 'text/plain' },
    body:    JSON.stringify({ action, ...payload }),
  }, 30000);
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`);
  const data = await res.json();
  if (data.error) throw new Error(data.error);
  return data;
}

export async function testConnection(url) {
  try {
    const testUrl = url + (url.includes('?') ? '&' : '?') + 'action=test';
    const res = await fetchWithTimeout(testUrl, {
      method:  'GET',
      headers: { 'Accept': 'application/json' },
    }, 10000);
    if (!res.ok) return { ok: false, error: `HTTP ${res.status}` };
    const data = await res.json().catch(() => null);
    if (!data) return { ok: false, error: 'Invalid response' };
    if (data.status === 'ok') return { ok: true, sheetName: data.sheetName || 'HP Parts' };
    return { ok: false, error: data.message || 'Script error' };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

export async function pushAll(parts) {
  return request('pushAll', { parts: parts.map(flattenPart) });
}

export async function pullAll() {
  const result = await request('pullAll');
  return (result.parts || []).map(expandPart);
}

export async function pushOne(part) {
  return request('upsertPart', { part: flattenPart(part) });
}

export { getSheetsUrl, setSheetsUrl };
