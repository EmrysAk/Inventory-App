// app/scan.jsx — Unified scan screen
//
// PHASES: pick → crop (single) | batch → review
// Crop mode: draw box inline with PanResponder. No navigation to separate screen.
//
// COORDINATE RULES (proven stable):
//   pageX/pageY   = absolute screen coords, never drift when finger slides over children
//   measure()     = called inside requestAnimationFrame so native view is ready
//   boxRef        = updated imperatively on every move, no per-move state re-renders
//   tick state    = incremented on release only, triggers overlay re-render once

import { useState, useRef, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, Image,
  ScrollView, Alert, ActivityIndicator, PanResponder, Dimensions,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { scanLabel, lookupPart, imageToBase64, cropImage } from '../src/services/ai';
import { addPart, loadSettings } from '../src/services/db';
import { C } from '../src/constants';

const MAX_BATCH = 5;
const { width: SCREEN_W } = Dimensions.get('window');

// ── Batch progress bar ────────────────────────────────────────────────────────

function BatchProgress({ current, total, label }) {
  return (
    <View style={s.progressWrap}>
      <View style={s.progressRow}>
        <Text style={s.progressCount}>Processing {current} of {total}</Text>
        <Text style={s.progressPct}>{Math.round((current / total) * 100)}%</Text>
      </View>
      <View style={s.progressTrack}>
        <View style={[s.progressFill, { width: `${(current / total) * 100}%` }]} />
      </View>
      <Text style={s.progressLabel}>{label}</Text>
    </View>
  );
}

// ── Thumbnail strip ───────────────────────────────────────────────────────────

function ThumbStrip({ assets, onRemove, disabled }) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 12 }}>
      <View style={{ flexDirection: 'row', gap: 8, paddingHorizontal: 2 }}>
        {assets.map((a, i) => (
          <View key={i} style={s.thumb}>
            <Image source={{ uri: a.uri }} style={s.thumbImg} />
            {!disabled && (
              <TouchableOpacity style={s.thumbX} onPress={() => onRemove(i)}>
                <Ionicons name="close-circle" size={18} color={C.danger} />
              </TouchableOpacity>
            )}
            <View style={s.thumbBadge}>
              <Text style={s.thumbNum}>{i + 1}</Text>
            </View>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

// ── Crop overlay (separate component, re-renders only when tick changes) ───────

function CropOverlay({ boxRef, fitW, fitH, imgLeft, confirmed }) {
  const b = boxRef.current;
  if (!b || b.w < 4 || b.h < 4) return null;
  const { x, y, w, h } = b;
  const col = confirmed ? C.success : C.accent;

  return (
    <>
      {/* Dim strips above / below / left / right of selection */}
      <View pointerEvents="none" style={[s.dim, { top: 0,   left: imgLeft,     width: fitW,         height: Math.max(0, y) }]} />
      <View pointerEvents="none" style={[s.dim, { top: y+h, left: imgLeft,     width: fitW,         height: Math.max(0, fitH - y - h) }]} />
      <View pointerEvents="none" style={[s.dim, { top: y,   left: imgLeft,     width: Math.max(0, x), height: h }]} />
      <View pointerEvents="none" style={[s.dim, { top: y,   left: imgLeft+x+w, width: Math.max(0, fitW - x - w), height: h }]} />

      {/* Selection border */}
      <View pointerEvents="none" style={[s.selBorder, { top: y, left: imgLeft + x, width: w, height: h, borderColor: col }]}>
        <View style={[s.corner, s.cornerTL, { borderColor: col }]} />
        <View style={[s.corner, s.cornerTR, { borderColor: col }]} />
        <View style={[s.corner, s.cornerBL, { borderColor: col }]} />
        <View style={[s.corner, s.cornerBR, { borderColor: col }]} />
      </View>
    </>
  );
}

// ── Result card ───────────────────────────────────────────────────────────────

function ResultCard({ item, index, total, qty, onQtyChange, onSave, onSkip, saved }) {
  const { ocr, ps } = item;
  return (
    <View style={s.resultCard}>
      <View style={s.resultHeader}>
        <Text style={s.resultIdx}>{index + 1} / {total}</Text>
        {saved
          ? <View style={s.savedBadge}><Text style={s.savedTxt}>✓ Saved</Text></View>
          : item.error
            ? <View style={s.errBadge}><Text style={s.errTxt}>⚠ Error</Text></View>
            : null}
      </View>

      <Image source={{ uri: item.asset.uri }} style={s.resultImg} resizeMode="cover" />

      {item.error ? (
        <Text style={s.errMsg}>{item.error}</Text>
      ) : (
        <>
          <View style={s.resultRow}><Text style={s.rLabel}>Part Number</Text><Text style={s.rValHi}>{ocr?.partNumber || '—'}</Text></View>
          <View style={s.resultRow}><Text style={s.rLabel}>Type</Text><Text style={s.rVal}>{ocr?.partType || '—'}</Text></View>
          <View style={s.resultRow}><Text style={s.rLabel}>Color</Text><Text style={s.rVal}>{ocr?.color || '—'}</Text></View>
          {ps && !ps.parseError && ps.fullDescription && (
            <View style={s.resultRow}>
              <Text style={s.rLabel}>HP Description</Text>
              <Text style={s.rVal} numberOfLines={2}>{ps.fullDescription}</Text>
            </View>
          )}

          {!saved && (
            <View style={s.qtyEditRow}>
              <Text style={s.rLabel}>Quantity</Text>
              <View style={s.qtyEditCtrls}>
                <TouchableOpacity style={s.qBtn} onPress={() => onQtyChange(Math.max(1, qty - 1))}>
                  <Ionicons name="remove" size={18} color={C.text} />
                </TouchableOpacity>
                <Text style={s.qNum}>{qty}</Text>
                <TouchableOpacity style={s.qBtn} onPress={() => onQtyChange(qty + 1)}>
                  <Ionicons name="add" size={18} color={C.text} />
                </TouchableOpacity>
              </View>
            </View>
          )}

          {!saved && (
            <View style={s.resultBtnRow}>
              <TouchableOpacity style={s.skipBtn} onPress={onSkip}>
                <Text style={s.skipTxt}>Skip</Text>
              </TouchableOpacity>
              <TouchableOpacity style={s.saveBtn} onPress={onSave}>
                <Ionicons name="checkmark-circle" size={18} color="#fff" />
                <Text style={s.saveTxt}>Save</Text>
              </TouchableOpacity>
            </View>
          )}
        </>
      )}
    </View>
  );
}

// ── Main screen ───────────────────────────────────────────────────────────────

const PHASE = { PICK: 'pick', CROP: 'crop', BATCH: 'batch', REVIEW: 'review' };

export default function ScanScreen() {
  const router = useRouter();

  // Phase state
  const [phase,    setPhase]    = useState(PHASE.PICK);

  // Crop phase
  const [cropUri,  setCropUri]  = useState(null);
  const [natW,     setNatW]     = useState(1);
  const [natH,     setNatH]     = useState(1);
  const [fitW,     setFitW]     = useState(1);
  const [fitH,     setFitH]     = useState(1);
  const [imgLeft,  setImgLeft]  = useState(0);
  const [drawing,  setDrawing]  = useState(false); // finger is down
  const [hasBox,   setHasBox]   = useState(false); // box drawn
  const [boxReady, setBoxReady] = useState(false); // box confirmed (released)
  const [tick,     setTick]     = useState(0);     // forces overlay redraw
  const [scanning, setScanning] = useState(false);
  const [scanLabel2, setScanLabel2] = useState('');

  // Batch phase
  const [batchAssets,  setBatchAssets]  = useState([]);
  const [batchProgress,setBatchProgress]= useState({ current: 0, total: 0, label: '' });

  // Review phase
  const [results, setResults] = useState([]);
  const [qtys,    setQtys]    = useState({});
  const [saved,   setSaved]   = useState({});

  // Refs for crop
  const wrapRef  = useRef(null);
  const originX  = useRef(0);  // wrapRef's screen X
  const originY  = useRef(0);  // wrapRef's screen Y
  const boxRef   = useRef({ x: 0, y: 0, w: 0, h: 0 });
  const startPt  = useRef({ x: 0, y: 0 });

  // ── Permissions ────────────────────────────────────────────────────────────

  async function requestCamera() {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') { Alert.alert('Permission Needed', 'Allow camera access in Settings.'); return false; }
    return true;
  }

  async function requestGallery() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('Permission Needed', 'Allow photo library access in Settings.'); return false; }
    return true;
  }

  // ── Crop mode entry ────────────────────────────────────────────────────────

  async function enterCropFromCamera() {
    if (!await requestCamera()) return;
    const result = await ImagePicker.launchCameraAsync({ quality: 1, base64: false });
    if (!result.canceled && result.assets?.[0]) {
      enterCrop(result.assets[0]);
    }
  }

  async function enterCropFromGallery() {
    if (!await requestGallery()) return;
    const result = await ImagePicker.launchImageLibraryAsync({ quality: 1, base64: false, allowsMultipleSelection: false });
    if (!result.canceled && result.assets?.[0]) {
      enterCrop(result.assets[0]);
    }
  }

  function enterCrop(asset) {
    setCropUri(asset.uri);
    setNatW(asset.width  || 1200);
    setNatH(asset.height || 1600);
    boxRef.current = { x: 0, y: 0, w: 0, h: 0 };
    setHasBox(false);
    setBoxReady(false);
    setDrawing(false);
    setTick(0);
    setScanning(false);
    setPhase(PHASE.CROP);
  }

  // ── Image layout — compute fit dimensions and left offset ─────────────────

  function onImageLayout(e) {
    const { width: containerW, height: containerH } = e.nativeEvent.layout;
    const aspect = natW / natH;
    let fw = containerW;
    let fh = containerW / aspect;
    if (fh > containerH) { fh = containerH; fw = containerH * aspect; }
    setFitW(fw);
    setFitH(fh);
    setImgLeft((containerW - fw) / 2);

    // Measure absolute position of the container on screen
    requestAnimationFrame(() => {
      wrapRef.current?.measure((_fx, _fy, _w, _h, px, py) => {
        originX.current = px;
        originY.current = py;
      });
    });
  }

  // ── PanResponder for crop drawing ─────────────────────────────────────────

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder:  () => true,
      onMoveShouldSetPanResponder:   () => true,

      onPanResponderGrant: (e) => {
        // Convert screen coords to image-relative coords
        const cx = Math.max(0, Math.min(e.nativeEvent.pageX - originX.current - imgLeft, fitW));
        const cy = Math.max(0, Math.min(e.nativeEvent.pageY - originY.current, fitH));
        startPt.current = { x: cx, y: cy };
        boxRef.current = { x: cx, y: cy, w: 0, h: 0 };
        setDrawing(true);
        setBoxReady(false);
        setHasBox(true);
        setTick(t => t + 1);
      },

      onPanResponderMove: (e) => {
        const cx = Math.max(0, Math.min(e.nativeEvent.pageX - originX.current - imgLeft, fitW));
        const cy = Math.max(0, Math.min(e.nativeEvent.pageY - originY.current, fitH));
        const sx = startPt.current.x;
        const sy = startPt.current.y;
        boxRef.current = {
          x: Math.min(sx, cx),
          y: Math.min(sy, cy),
          w: Math.abs(cx - sx),
          h: Math.abs(cy - sy),
        };
        // Do NOT setState here — boxRef is read imperatively in the overlay
        // We only trigger a re-render via tick on release
      },

      onPanResponderRelease: () => {
        setDrawing(false);
        setBoxReady(boxRef.current.w > 20 && boxRef.current.h > 20);
        setTick(t => t + 1); // now redraw overlay with final position
      },
    })
  ).current;

  // ── Crop and scan ──────────────────────────────────────────────────────────

  async function doScan(useCrop) {
    setScanning(true);
    setScanLabel2(useCrop ? 'Cropping image...' : 'Reading image...');
    try {
      const settings = await loadSettings();
      let base64;
      let uriToRead = cropUri;

      if (useCrop && boxRef.current.w > 20 && boxRef.current.h > 20) {
        const b   = boxRef.current;
        const pad = 12;
        const rx  = Math.max(0, Math.round(((b.x - pad) / fitW) * natW));
        const ry  = Math.max(0, Math.round(((b.y - pad) / fitH) * natH));
        const rw  = Math.min(natW - rx, Math.round(((b.w + pad * 2) / fitW) * natW));
        const rh  = Math.min(natH - ry, Math.round(((b.h + pad * 2) / fitH) * natH));
        setScanLabel2('Cropping selection...');
        uriToRead = await cropImage(cropUri, rx, ry, rw, rh);
      }

      setScanLabel2('Reading with AI...');
      base64 = await imageToBase64(uriToRead);
      const ocr = await scanLabel(base64, 'image/jpeg', settings);

      setScanLabel2('Looking up part details...');
      const ps = await lookupPart(ocr?.partNumber, settings);

      if (ocr?.partNumber) {
        await addPart(ocr, ps, cropUri, 1);
        setScanning(false);
        Alert.alert(
          'Part Saved ✓',
          `${ocr.partNumber}${ps?.fullDescription ? '\n' + ps.fullDescription : ''}`,
          [
            { text: 'Scan Another', onPress: () => setPhase(PHASE.PICK) },
            { text: 'Done', onPress: () => router.back() },
          ]
        );
      } else {
        setScanning(false);
        Alert.alert(
          'No Part Number Found',
          'AI could not read a part number. Try:\n• Draw a tighter box around the part number\n• Better lighting or angle',
          [
            { text: 'Try Again', style: 'cancel' },
            { text: 'Save Anyway', onPress: async () => {
              await addPart(ocr || {}, ps || {}, cropUri, 1);
              router.back();
            }},
          ]
        );
      }
    } catch (err) {
      setScanning(false);
      Alert.alert('Scan Error', err.message);
    }
  }

  // ── Batch mode ────────────────────────────────────────────────────────────

  async function pickBatchCamera() {
    if (!await requestCamera()) return;
    const result = await ImagePicker.launchCameraAsync({ quality: 0.9, base64: true });
    if (!result.canceled && result.assets?.[0]) {
      const next = [...batchAssets, result.assets[0]].slice(0, MAX_BATCH);
      setBatchAssets(next);
      if (next.length >= MAX_BATCH) {
        runBatch(next);
      } else {
        Alert.alert(
          `${next.length} photo${next.length > 1 ? 's' : ''} ready`,
          `Add another (up to ${MAX_BATCH}) or process now?`,
          [
            { text: 'Add Another', onPress: pickBatchCamera },
            { text: 'Process Now', onPress: () => runBatch(next) },
          ]
        );
      }
    }
  }

  async function pickBatchGallery() {
    if (!await requestGallery()) return;
    const result = await ImagePicker.launchImageLibraryAsync({
      quality: 0.85, base64: true,
      allowsMultipleSelection: true,
      selectionLimit: MAX_BATCH,
    });
    if (!result.canceled && result.assets?.length) {
      const assets = result.assets.slice(0, MAX_BATCH);
      setBatchAssets(assets);
      runBatch(assets);
    }
  }

  async function runBatch(assets) {
    const settings = await loadSettings();
    const model    = settings.aiModel || 'vision';

    // Check key before starting
    const needsKey = model === 'vision'
      ? !(settings.visionKey && settings.geminiKey)
      : model === 'gemini' ? !settings.geminiKey
      : model === 'gpt'    ? !settings.openaiKey
      : !settings.claudeKey;

    if (needsKey) {
      Alert.alert(
        'API Key Required',
        'Add your API key in Settings before scanning.',
        [
          { text: 'Settings', onPress: () => router.push('/settings') },
          { text: 'Cancel', style: 'cancel' },
        ]
      );
      return;
    }

    setPhase(PHASE.BATCH);

    // Delay between scans to avoid rate limits
    const delays = { gemini: 10000, gpt: 2000, claude: 1000, vision: 1000 };
    const delay  = delays[model] || 2000;

    const batchResults = [];
    for (let i = 0; i < assets.length; i++) {
      setBatchProgress({ current: i + 1, total: assets.length, label: `Reading label ${i + 1} of ${assets.length}...` });

      if (i > 0) {
        const secs = Math.round(delay / 1000);
        setBatchProgress(p => ({ ...p, label: `Waiting ${secs}s to avoid rate limits...` }));
        await new Promise(r => setTimeout(r, delay));
      }

      try {
        setBatchProgress(p => ({ ...p, label: `Scanning with AI (${i + 1}/${assets.length})...` }));
        let base64 = assets[i].base64;
        if (!base64) {
          base64 = await imageToBase64(assets[i].uri);
        }

        let ocr;
        for (let retry = 0; retry < 3; retry++) {
          try {
            ocr = await scanLabel(base64, assets[i].mimeType || 'image/jpeg', settings);
            break;
          } catch (err) {
            if (/429|RESOURCE_EXHAUSTED/i.test(err.message) && retry < 2) {
              setBatchProgress(p => ({ ...p, label: `Rate limited — retrying in ${(retry + 1) * 5}s...` }));
              await new Promise(r => setTimeout(r, (retry + 1) * 5000));
            } else throw err;
          }
        }

        setBatchProgress(p => ({ ...p, label: `Looking up ${ocr?.partNumber || 'part'}...` }));
        const ps = await lookupPart(ocr?.partNumber, settings);
        batchResults.push({ asset: assets[i], ocr, ps, error: null });
      } catch (err) {
        batchResults.push({ asset: assets[i], ocr: null, ps: null, error: err.message });
      }
    }

    const initQtys = {};
    batchResults.forEach((_, i) => { initQtys[i] = 1; });
    setResults(batchResults);
    setQtys(initQtys);
    setSaved({});
    setPhase(PHASE.REVIEW);
  }

  async function handleSaveResult(index) {
    const item = results[index];
    try {
      await addPart(item.ocr || {}, item.ps || {}, item.asset.uri, qtys[index] || 1);
      setSaved(prev => ({ ...prev, [index]: true }));
    } catch (err) {
      Alert.alert('Save Error', err.message);
    }
  }

  async function handleSaveAll() {
    for (let i = 0; i < results.length; i++) {
      if (!saved[i] && !results[i].error) await handleSaveResult(i);
    }
    router.back();
  }

  function resetAll() {
    setBatchAssets([]);
    setResults([]);
    setQtys({});
    setSaved({});
    setCropUri(null);
    setPhase(PHASE.PICK);
  }

  // ── RENDER: PICK ──────────────────────────────────────────────────────────

  if (phase === PHASE.PICK) {
    return (
      <View style={s.screen}>
        <ScrollView contentContainerStyle={s.scroll}>
          <Text style={s.title}>📸 Scan Part</Text>
          <Text style={s.subtitle}>Select region mode for best accuracy, or batch scan up to {MAX_BATCH} images at once.</Text>

          {/* Region select (recommended) */}
          <View style={s.modeBox}>
            <View style={s.modeLabelRow}>
              <View style={s.bestBadge}><Text style={s.bestTxt}>⭐ BEST ACCURACY</Text></View>
              <Text style={s.modeTitle}>Select Region Mode</Text>
            </View>
            <Text style={s.modeHint}>Draw a box around the part number — AI reads just that area</Text>
            <View style={s.modeBtnRow}>
              <TouchableOpacity style={[s.modeBtn, { backgroundColor: '#1A2A3A' }]} onPress={enterCropFromCamera}>
                <Ionicons name="camera" size={20} color={C.accent} />
                <Text style={[s.modeBtnTxt, { color: C.accent }]}>Camera + Select</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.modeBtn, { backgroundColor: '#1A2A2A' }]} onPress={enterCropFromGallery}>
                <Ionicons name="images" size={20} color={C.success} />
                <Text style={[s.modeBtnTxt, { color: C.success }]}>Gallery + Select</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Divider */}
          <View style={s.divider}>
            <View style={s.divLine} /><Text style={s.divTxt}>or scan full image / batch</Text><View style={s.divLine} />
          </View>

          {/* Batch camera */}
          <TouchableOpacity style={s.bigBtn} onPress={pickBatchCamera}>
            <Ionicons name="camera" size={22} color="#fff" />
            <Text style={s.bigBtnTxt}>
              {batchAssets.length > 0 ? `Add Another Photo (${batchAssets.length}/${MAX_BATCH})` : 'Take Photo — Full Image'}
            </Text>
          </TouchableOpacity>

          {/* Batch gallery */}
          <TouchableOpacity style={[s.bigBtn, s.bigBtnOutline]} onPress={pickBatchGallery}>
            <Ionicons name="images" size={22} color={C.accent} />
            <Text style={[s.bigBtnTxt, { color: C.accent }]}>Select Up to {MAX_BATCH} from Gallery</Text>
          </TouchableOpacity>

          {batchAssets.length > 0 && (
            <>
              <ThumbStrip assets={batchAssets} onRemove={i => setBatchAssets(prev => prev.filter((_, idx) => idx !== i))} />
              <TouchableOpacity style={[s.bigBtn, { backgroundColor: C.success }]} onPress={() => runBatch(batchAssets)}>
                <Ionicons name="flash" size={20} color="#fff" />
                <Text style={s.bigBtnTxt}>Process {batchAssets.length} Photo{batchAssets.length > 1 ? 's' : ''}</Text>
              </TouchableOpacity>
            </>
          )}

          <View style={s.tipBox}>
            <Text style={s.tipTitle}>💡 Tips for Best Results</Text>
            <Text style={s.tip}>• Use Camera + Select and draw a box around the part number</Text>
            <Text style={s.tip}>• HP part number must be clearly visible (e.g. CE505A)</Text>
            <Text style={s.tip}>• Fill the frame with the label — avoid glare</Text>
            <Text style={s.tip}>• Each scan takes ~5–10 seconds</Text>
          </View>
        </ScrollView>
      </View>
    );
  }

  // ── RENDER: CROP ──────────────────────────────────────────────────────────

  if (phase === PHASE.CROP) {
    return (
      <View style={s.screen}>
        <View style={s.cropHeader}>
          <TouchableOpacity onPress={() => setPhase(PHASE.PICK)} style={s.cropBack}>
            <Ionicons name="arrow-back" size={22} color={C.text} />
          </TouchableOpacity>
          <Text style={s.cropTitle}>
            {drawing ? 'Drawing...' : hasBox ? (boxReady ? 'Region selected' : 'Box too small') : 'Draw a box around the part number'}
          </Text>
        </View>

        {/* Image + crop canvas */}
        <View
          ref={wrapRef}
          style={s.cropCanvas}
          onLayout={onImageLayout}
          {...panResponder.panHandlers}
        >
          <Image
            source={{ uri: cropUri }}
            style={{ width: fitW, height: fitH, marginLeft: imgLeft }}
            resizeMode="contain"
            pointerEvents="none"
          />
          <View style={[StyleSheet.absoluteFillObject]} pointerEvents="none">
            <CropOverlay
              key={tick}
              boxRef={boxRef}
              fitW={fitW}
              fitH={fitH}
              imgLeft={imgLeft}
              confirmed={boxReady}
            />
          </View>
        </View>

        {/* Action buttons */}
        <View style={s.cropActions}>
          {scanning ? (
            <View style={s.scanningRow}>
              <ActivityIndicator color={C.accent} />
              <Text style={s.scanningTxt}>{scanLabel2}</Text>
            </View>
          ) : (
            <>
              {boxReady && (
                <TouchableOpacity style={[s.actionBtn, { backgroundColor: C.accent }]} onPress={() => doScan(true)}>
                  <Ionicons name="scan" size={20} color="#fff" />
                  <Text style={s.actionBtnTxt}>Scan Selected Region</Text>
                </TouchableOpacity>
              )}
              <TouchableOpacity style={[s.actionBtn, { backgroundColor: C.surface, borderWidth: 1, borderColor: C.border }]} onPress={() => doScan(false)}>
                <Ionicons name="image" size={20} color={C.muted} />
                <Text style={[s.actionBtnTxt, { color: C.muted }]}>Scan Full Image</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.actionBtn, { backgroundColor: C.surface, borderWidth: 1, borderColor: C.border }]} onPress={() => { setPhase(PHASE.PICK); setCropUri(null); }}>
                <Text style={[s.actionBtnTxt, { color: C.muted }]}>Cancel</Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </View>
    );
  }

  // ── RENDER: BATCH PROCESSING ──────────────────────────────────────────────

  if (phase === PHASE.BATCH) {
    const current = batchAssets[batchProgress.current - 1];
    return (
      <View style={s.screen}>
        <ScrollView contentContainerStyle={s.scroll}>
          <Text style={s.title}>🔍 Processing Batch...</Text>
          <BatchProgress current={batchProgress.current} total={batchProgress.total} label={batchProgress.label} />
          {current && <Image source={{ uri: current.uri }} style={s.batchCurrentImg} resizeMode="contain" />}
          <View style={s.processingCard}>
            <ActivityIndicator size="large" color={C.accent} />
            <Text style={s.processingTxt}>{batchProgress.label}</Text>
            <Text style={s.processingNote}>Do not close the app</Text>
          </View>
          <ThumbStrip assets={batchAssets} onRemove={() => {}} disabled />
        </ScrollView>
      </View>
    );
  }

  // ── RENDER: REVIEW ────────────────────────────────────────────────────────

  const savedCount   = Object.values(saved).filter(Boolean).length;
  const errorCount   = results.filter(r => r.error).length;
  const pendingCount = results.filter((r, i) => !saved[i] && !r.error).length;

  return (
    <View style={s.screen}>
      <ScrollView contentContainerStyle={s.scroll}>

        <View style={s.summaryBar}>
          <View style={s.sumItem}><Text style={s.sumNum}>{results.length}</Text><Text style={s.sumLbl}>Scanned</Text></View>
          <View style={s.sumDivider} />
          <View style={s.sumItem}><Text style={[s.sumNum, { color: C.success }]}>{savedCount}</Text><Text style={s.sumLbl}>Saved</Text></View>
          <View style={s.sumDivider} />
          <View style={s.sumItem}><Text style={[s.sumNum, { color: C.warning }]}>{pendingCount}</Text><Text style={s.sumLbl}>Pending</Text></View>
          {errorCount > 0 && <>
            <View style={s.sumDivider} />
            <View style={s.sumItem}><Text style={[s.sumNum, { color: C.danger }]}>{errorCount}</Text><Text style={s.sumLbl}>Failed</Text></View>
          </>}
        </View>

        {results.map((item, i) => (
          <ResultCard
            key={i}
            item={item}
            index={i}
            total={results.length}
            qty={qtys[i] || 1}
            onQtyChange={v => setQtys(prev => ({ ...prev, [i]: v }))}
            onSave={() => handleSaveResult(i)}
            onSkip={() => setSaved(prev => ({ ...prev, [i]: true }))}
            saved={!!saved[i]}
          />
        ))}

        <View style={s.bottomActions}>
          {pendingCount > 1 && (
            <TouchableOpacity style={[s.bigBtn, { backgroundColor: C.success }]} onPress={handleSaveAll}>
              <Ionicons name="checkmark-done-circle" size={20} color="#fff" />
              <Text style={s.bigBtnTxt}>Save All {pendingCount} Remaining</Text>
            </TouchableOpacity>
          )}
          <View style={s.bottomRow}>
            <TouchableOpacity style={s.scanMoreBtn} onPress={resetAll}>
              <Ionicons name="camera-outline" size={18} color={C.accent} />
              <Text style={s.scanMoreTxt}>Scan More</Text>
            </TouchableOpacity>
            <TouchableOpacity style={s.doneBtn} onPress={() => router.back()}>
              <Text style={s.doneTxt}>Done</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────

const s = StyleSheet.create({
  screen:   { flex: 1, backgroundColor: C.bg },
  scroll:   { padding: 16, paddingBottom: 60 },
  title:    { fontSize: 20, fontWeight: '800', color: C.text, marginBottom: 6 },
  subtitle: { fontSize: 13, color: C.muted, marginBottom: 18, lineHeight: 20 },

  // Pick phase
  modeBox:     { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 14, padding: 16, marginBottom: 16 },
  modeLabelRow:{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 6 },
  bestBadge:   { backgroundColor: '#2A2500', borderRadius: 4, paddingHorizontal: 6, paddingVertical: 2 },
  bestTxt:     { fontSize: 9, color: C.warning, fontWeight: '800', letterSpacing: 0.5 },
  modeTitle:   { fontSize: 14, fontWeight: '700', color: C.text },
  modeHint:    { fontSize: 12, color: C.muted, marginBottom: 12, lineHeight: 18 },
  modeBtnRow:  { flexDirection: 'row', gap: 10 },
  modeBtn:     { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderRadius: 10, paddingVertical: 14 },
  modeBtnTxt:  { fontWeight: '700', fontSize: 13 },

  divider:  { flexDirection: 'row', alignItems: 'center', marginVertical: 14, gap: 10 },
  divLine:  { flex: 1, height: 1, backgroundColor: C.border },
  divTxt:   { fontSize: 11, color: C.muted },

  bigBtn:        { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, backgroundColor: C.accent, borderRadius: 14, paddingVertical: 18, marginBottom: 10 },
  bigBtnOutline: { backgroundColor: 'transparent', borderWidth: 2, borderColor: C.accent },
  bigBtnTxt:     { color: '#fff', fontSize: 15, fontWeight: '700' },

  tipBox:   { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 12, padding: 16, marginTop: 8 },
  tipTitle: { color: C.text, fontWeight: '700', marginBottom: 8 },
  tip:      { color: C.muted, fontSize: 12.5, lineHeight: 22 },

  // Thumbnail strip
  thumb:      { width: 72, height: 72, borderRadius: 10, overflow: 'visible' },
  thumbImg:   { width: 72, height: 72, borderRadius: 10, backgroundColor: C.border },
  thumbX:     { position: 'absolute', top: -6, right: -6, zIndex: 10 },
  thumbBadge: { position: 'absolute', bottom: 4, left: 4, backgroundColor: 'rgba(0,0,0,.65)', borderRadius: 6, paddingHorizontal: 5, paddingVertical: 1 },
  thumbNum:   { fontSize: 10, color: '#fff', fontWeight: '700' },

  // Crop phase
  cropHeader: { flexDirection: 'row', alignItems: 'center', padding: 12, gap: 10, borderBottomWidth: 1, borderBottomColor: C.border },
  cropBack:   { padding: 4 },
  cropTitle:  { flex: 1, fontSize: 13, color: C.text, fontWeight: '600' },
  cropCanvas: { flex: 1, backgroundColor: '#000', justifyContent: 'center', alignItems: 'center' },

  dim:      { position: 'absolute', backgroundColor: 'rgba(0,0,0,0.55)' },
  selBorder:{ position: 'absolute', borderWidth: 2 },
  corner:   { position: 'absolute', width: 20, height: 20, borderColor: 'transparent' },
  cornerTL: { top: -1, left: -1, borderTopWidth: 3, borderLeftWidth: 3 },
  cornerTR: { top: -1, right: -1, borderTopWidth: 3, borderRightWidth: 3 },
  cornerBL: { bottom: -1, left: -1, borderBottomWidth: 3, borderLeftWidth: 3 },
  cornerBR: { bottom: -1, right: -1, borderBottomWidth: 3, borderRightWidth: 3 },

  cropActions:  { padding: 16, gap: 10, borderTopWidth: 1, borderTopColor: C.border },
  scanningRow:  { flexDirection: 'row', alignItems: 'center', gap: 12, justifyContent: 'center', paddingVertical: 14 },
  scanningTxt:  { color: C.text, fontSize: 14 },
  actionBtn:    { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, borderRadius: 12, paddingVertical: 15 },
  actionBtnTxt: { color: '#fff', fontWeight: '700', fontSize: 15 },

  // Batch processing
  progressWrap:  { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 14, padding: 16, marginBottom: 14 },
  progressRow:   { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  progressCount: { fontSize: 13, fontWeight: '700', color: C.text },
  progressPct:   { fontSize: 13, color: C.accent, fontWeight: '700' },
  progressTrack: { height: 6, backgroundColor: C.border, borderRadius: 3, overflow: 'hidden', marginBottom: 8 },
  progressFill:  { height: '100%', backgroundColor: C.accent, borderRadius: 3 },
  progressLabel: { fontSize: 12, color: C.muted },

  batchCurrentImg: { width: '100%', height: 200, borderRadius: 12, marginBottom: 14, backgroundColor: C.card },
  processingCard:  { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 14, padding: 28, alignItems: 'center', gap: 12, marginBottom: 14 },
  processingTxt:   { fontSize: 14, color: C.text, textAlign: 'center', fontWeight: '600' },
  processingNote:  { fontSize: 11, color: C.muted },

  // Review phase
  summaryBar:  { flexDirection: 'row', backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 14, padding: 16, marginBottom: 14, justifyContent: 'space-around', alignItems: 'center' },
  sumItem:     { alignItems: 'center' },
  sumNum:      { fontSize: 24, fontWeight: '800', color: C.text },
  sumLbl:      { fontSize: 11, color: C.muted, marginTop: 2 },
  sumDivider:  { width: 1, height: 36, backgroundColor: C.border },

  resultCard:   { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 14, padding: 14, marginBottom: 14 },
  resultHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  resultIdx:    { fontSize: 12, color: C.muted, fontWeight: '700' },
  savedBadge:   { backgroundColor: '#064E3B', borderRadius: 6, paddingHorizontal: 8, paddingVertical: 2 },
  savedTxt:     { color: C.success, fontSize: 11, fontWeight: '700' },
  errBadge:     { backgroundColor: '#451A03', borderRadius: 6, paddingHorizontal: 8, paddingVertical: 2 },
  errTxt:       { color: C.warning, fontSize: 11, fontWeight: '700' },
  resultImg:    { width: '100%', height: 130, borderRadius: 10, marginBottom: 10, backgroundColor: C.surface },
  resultRow:    { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  rLabel:       { fontSize: 11, color: C.muted, textTransform: 'uppercase', flex: 1 },
  rVal:         { fontSize: 13, color: C.text, flex: 2, textAlign: 'right' },
  rValHi:       { fontSize: 15, color: C.accent, fontWeight: '800', flex: 2, textAlign: 'right' },
  errMsg:       { color: C.danger, fontSize: 13, marginTop: 4, lineHeight: 20 },

  qtyEditRow:   { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 10 },
  qtyEditCtrls: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  qBtn:         { width: 34, height: 34, borderRadius: 8, backgroundColor: C.border, alignItems: 'center', justifyContent: 'center' },
  qNum:         { fontSize: 20, fontWeight: '800', color: C.accent, minWidth: 30, textAlign: 'center' },

  resultBtnRow: { flexDirection: 'row', gap: 10, marginTop: 12 },
  skipBtn:      { flex: 1, paddingVertical: 12, borderRadius: 10, borderWidth: 1, borderColor: C.border, alignItems: 'center' },
  skipTxt:      { color: C.muted, fontWeight: '600' },
  saveBtn:      { flex: 2, flexDirection: 'row', gap: 6, paddingVertical: 12, borderRadius: 10, backgroundColor: C.success, alignItems: 'center', justifyContent: 'center' },
  saveTxt:      { color: '#fff', fontWeight: '800', fontSize: 14 },

  bottomActions: { gap: 10, marginTop: 4 },
  bottomRow:     { flexDirection: 'row', gap: 10 },
  scanMoreBtn:   { flex: 1, flexDirection: 'row', gap: 6, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: C.accent, borderRadius: 12, paddingVertical: 13 },
  scanMoreTxt:   { color: C.accent, fontWeight: '700' },
  doneBtn:       { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 12, paddingVertical: 13 },
  doneTxt:       { color: C.text, fontWeight: '700' },
});
