// app/_layout.jsx
import { Stack } from 'expo-router';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';

export default function RootLayout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <StatusBar style="light" />
        <Stack
          screenOptions={{
            headerStyle:     { backgroundColor: '#0A0F1C' },
            headerTintColor: '#EEF2FF',
            headerTitleStyle:{ fontWeight: '700' },
            contentStyle:    { backgroundColor: '#0A0F1C' },
          }}
        >
          <Stack.Screen name="index"     options={{ title: 'HP Parts Inventory' }} />
          <Stack.Screen name="scan"      options={{ title: 'Scan Part' }} />
          <Stack.Screen name="export"    options={{ title: 'Export' }} />
          <Stack.Screen name="pcsync"    options={{ title: 'PC Sync' }} />
          <Stack.Screen name="settings"  options={{ title: 'Settings' }} />
          <Stack.Screen name="item/[id]" options={{ title: 'Part Detail' }} />
        </Stack>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
