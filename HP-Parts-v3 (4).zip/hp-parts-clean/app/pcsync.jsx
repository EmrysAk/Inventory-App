// app/pcsync.jsx — PC Wi-Fi Sync

import { useState, useEffect } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  TextInput, Alert, ActivityIndicator, ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { loadParts, addPart } from '../src/services/db';
import { testConnection, pushAllToPC, pullFromPC, getPcHost, setPcHost } from '../src/services/pcsync';
import { C } from '../src/constants';

export default function PCSyncScreen() {
  const [host,       setHost]       = useState('');
  const [savedHost,  setSavedHost]  = useState('');
  const [testing,    setTesting]    = useState(false);
  const [connected,  setConnected]  = useState(false);
  const [syncing,    setSyncing]    = useState(false);
  const [syncResult, setSyncResult] = useState(null);

  useEffect(() => {
    getPcHost().then(h => { if (h) { setHost(h); setSavedHost(h); } });
  }, []);

  async function handleTest() {
    if (!host.trim()) { Alert.alert('Required', 'Enter the PC sync URL first.'); return; }
    setTesting(true);
    const r = await testConnection(host.trim());
    setTesting(false);
    if (r.ok) {
      setConnected(true);
      await setPcHost(host.trim());
      setSavedHost(host.trim());
      Alert.alert('Connected!', `HP Parts Inventory PC app found.\n${r.info?.app || ''}`);
    } else {
      setConnected(false);
      Alert.alert('Connection Failed', `Could not reach PC:\n${r.error}\n\nMake sure:\n• Both devices on same Wi-Fi\n• PC app is running\n• Sync server is active`);
    }
  }

  async function handlePush() {
    const parts = await loadParts();
    if (!parts.length) { Alert.alert('Nothing to sync', 'Scan some parts first.'); return; }
    setSyncing(true); setSyncResult(null);
    const r = await pushAllToPC(parts);
    setSyncing(false);
    if (r.ok || r.success) {
      setSyncResult({ type: 'success', msg: `✓ Sent ${parts.length} parts to PC — ${r.added || 0} new, ${r.updated || 0} updated` });
    } else if (r.skipped) {
      Alert.alert('Not Connected', 'Set up PC connection first.');
    } else {
      setSyncResult({ type: 'error', msg: `Push failed: ${r.error}` });
    }
  }

  async function handlePull() {
    setSyncing(true); setSyncResult(null);
    const r = await pullFromPC();
    setSyncing(false);
    if (r.ok && r.parts?.length) {
      let added = 0;
      for (const part of r.parts) {
        try {
          const res = await addPart(
            { partNumber: part.partNumber, serialNumber: (part.serialNumbers || [])[0], ...part },
            part,
            null,
            part.quantity || 1
          );
          if (res.isNew) added++;
        } catch {}
      }
      setSyncResult({ type: 'success', msg: `✓ Pulled ${r.parts.length} parts from PC (${added} new)` });
    } else if (r.skipped) {
      Alert.alert('Not Connected', 'Set up PC connection first.');
    } else {
      setSyncResult({ type: 'error', msg: `Pull failed: ${r.error || 'No data received'}` });
    }
  }

  return (
    <View style={s.container}>
      <ScrollView contentContainerStyle={s.scroll}>

        <View style={s.section}>
          <Text style={s.sectionTitle}>🖥️ PC Connection</Text>
          <Text style={s.desc}>Enter the URL shown in the HP Parts Inventory desktop app (Settings → Sync Server). Both devices must be on the same Wi-Fi network.</Text>
          <Text style={s.fieldLabel}>PC Sync Server URL</Text>
          <View style={s.inputRow}>
            <TextInput
              style={s.input}
              value={host}
              onChangeText={setHost}
              placeholder="http://192.168.1.100:4747"
              placeholderTextColor={C.muted}
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="url"
            />
            {connected && <Ionicons name="checkmark-circle" size={22} color={C.success} style={{ flexShrink: 0 }} />}
          </View>
          <TouchableOpacity style={s.testBtn} onPress={handleTest} disabled={testing}>
            {testing ? <ActivityIndicator size="small" color="#fff" /> : <Ionicons name="wifi" size={18} color="#fff" />}
            <Text style={s.testBtnTxt}>{testing ? 'Testing...' : 'Test Connection'}</Text>
          </TouchableOpacity>
          {savedHost ? (
            <Text style={s.savedHint}>Connected to: <Text style={{ color: C.accent }}>{savedHost}</Text></Text>
          ) : null}
        </View>

        <View style={s.section}>
          <Text style={s.sectionTitle}>🔄 Sync Actions</Text>
          {syncing ? (
            <View style={s.syncingWrap}>
              <ActivityIndicator size="large" color={C.accent} />
              <Text style={s.syncingTxt}>Syncing with PC...</Text>
            </View>
          ) : (
            <>
              <TouchableOpacity style={s.syncBtn} onPress={handlePush}>
                <View style={s.syncIcon}><Ionicons name="arrow-up-circle" size={28} color={C.accent} /></View>
                <View style={{ flex: 1 }}>
                  <Text style={s.syncTitle}>Push Phone → PC</Text>
                  <Text style={s.syncDesc}>Send all scanned parts from phone to desktop app</Text>
                </View>
                <Ionicons name="chevron-forward" size={16} color={C.muted} />
              </TouchableOpacity>

              <TouchableOpacity style={s.syncBtn} onPress={handlePull}>
                <View style={s.syncIcon}><Ionicons name="arrow-down-circle" size={28} color={C.success} /></View>
                <View style={{ flex: 1 }}>
                  <Text style={s.syncTitle}>Pull PC → Phone</Text>
                  <Text style={s.syncDesc}>Download inventory from desktop to phone</Text>
                </View>
                <Ionicons name="chevron-forward" size={16} color={C.muted} />
              </TouchableOpacity>
            </>
          )}

          {syncResult && (
            <View style={[s.resultBox, syncResult.type === 'success' ? s.resultOk : s.resultErr]}>
              <Text style={[s.resultTxt, { color: syncResult.type === 'success' ? C.success : C.danger }]}>
                {syncResult.msg}
              </Text>
            </View>
          )}
        </View>

        <View style={s.section}>
          <Text style={s.sectionTitle}>📋 How to Connect</Text>
          {[
            ['1', 'Open HP Parts Inventory on your PC'],
            ['2', 'Go to Sync page — the QR code shows the URL'],
            ['3', 'Enter that URL above (e.g. http://192.168.1.x:4747)'],
            ['4', 'Tap Test Connection to verify'],
            ['5', 'Use Push or Pull to sync inventory'],
          ].map(([n, t]) => (
            <View key={n} style={s.step}>
              <View style={s.stepNum}><Text style={s.stepNumTxt}>{n}</Text></View>
              <Text style={s.stepTxt}>{t}</Text>
            </View>
          ))}
        </View>

      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  container:   { flex: 1, backgroundColor: C.bg },
  scroll:      { padding: 16, paddingBottom: 48 },
  section:     { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 14, padding: 18, marginBottom: 16 },
  sectionTitle:{ fontSize: 15, fontWeight: '800', color: C.text, marginBottom: 8 },
  desc:        { fontSize: 12.5, color: C.muted, lineHeight: 20, marginBottom: 16 },
  fieldLabel:  { fontSize: 10, color: C.muted, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 },
  inputRow:    { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 },
  input:       { flex: 1, backgroundColor: C.bg, borderWidth: 1, borderColor: C.border, borderRadius: 9, padding: 12, color: C.text, fontSize: 14, fontFamily: 'monospace' },
  testBtn:     { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: C.accent, borderRadius: 10, paddingVertical: 13 },
  testBtnTxt:  { color: '#fff', fontWeight: '700', fontSize: 14 },
  savedHint:   { fontSize: 12, color: C.muted, marginTop: 8 },
  syncingWrap: { alignItems: 'center', paddingVertical: 24, gap: 12 },
  syncingTxt:  { color: C.muted, fontSize: 14 },
  syncBtn:     { flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: C.border },
  syncIcon:    { width: 44, height: 44, borderRadius: 12, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center' },
  syncTitle:   { fontSize: 14, fontWeight: '700', color: C.text, marginBottom: 3 },
  syncDesc:    { fontSize: 12, color: C.muted, lineHeight: 18 },
  resultBox:   { marginTop: 14, padding: 14, borderRadius: 10, borderWidth: 1 },
  resultOk:    { borderColor: C.success, backgroundColor: 'rgba(52,211,153,.08)' },
  resultErr:   { borderColor: C.danger,  backgroundColor: 'rgba(248,113,113,.08)' },
  resultTxt:   { fontSize: 13, fontWeight: '600' },
  step:        { flexDirection: 'row', gap: 12, marginBottom: 12, alignItems: 'flex-start' },
  stepNum:     { width: 24, height: 24, borderRadius: 12, backgroundColor: C.accent, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  stepNumTxt:  { color: '#fff', fontWeight: '800', fontSize: 11 },
  stepTxt:     { flex: 1, fontSize: 13, color: C.muted, lineHeight: 20, paddingTop: 2 },
});
