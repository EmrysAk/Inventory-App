// app/settings.jsx — Settings

import { useState, useCallback } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, Alert, Linking, ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from 'expo-router';
import { loadSettings, saveSettings, loadParts, loadUsage, resetUsage, getSheetsUrl, setSheetsUrl } from '../src/services/db';
import { testConnection } from '../src/services/sheets';
import { AI_MODELS, MODEL_ORDER } from '../src/constants';
import { formatCost } from '../src/services/ai';
import { C } from '../src/constants';

// Pricing table for display — matches AI_MODELS
const PRICING = {
  vision: { input: 0.00,  output: 0.0015, note: '$0 first 1K/mo · $0.0015/call after' },
  gemini: { input: 0.08,  output: 0.30 },
  gpt:    { input: 0.15,  output: 0.60 },
  claude: { input: 1.00,  output: 5.00 },
};

function SectionHeader({ icon, title, color }) {
  return (
    <View style={s.secHeader}>
      <Ionicons name={icon} size={16} color={color || C.accent} />
      <Text style={[s.secTitle, { color: color || C.accent }]}>{title}</Text>
    </View>
  );
}

export default function SettingsScreen() {
  const [form, setForm] = useState({
    aiModel: 'vision', visionKey: '', geminiKey: '', openaiKey: '', claudeKey: '',
    techName: '', location: '',
  });
  const [showKeys, setShowKeys] = useState({ vision: false, gemini: false, gpt: false, claude: false });
  const [saved,    setSaved]    = useState(false);
  const [partCount,setPartCount]= useState(0);
  const [usage,    setUsage]    = useState({});
  const [sheetUrl, setSheetUrlState] = useState('');
  const [sheetStatus, setSheetStatus]= useState(null); // 'ok' | 'error'
  const [sheetMsg, setSheetMsg]      = useState('');
  const [sheetLoading, setSheetLoading] = useState(false);

  useFocusEffect(useCallback(() => {
    loadSettings().then(st => setForm({
      aiModel:   st.aiModel   || 'vision',
      visionKey: st.visionKey || '',
      geminiKey: st.geminiKey || '',
      openaiKey: st.openaiKey || '',
      claudeKey: st.claudeKey || '',
      techName:  st.techName  || '',
      location:  st.location  || '',
    }));
    loadParts().then(p => setPartCount(p.length));
    loadUsage().then(setUsage);
    getSheetsUrl().then(u => { if (u) setSheetUrlState(u); });
  }, []));

  function set(k, v) { setForm(f => ({ ...f, [k]: v })); }

  // Model tap instantly saves
  async function selectModel(id) {
    const updated = { ...form, aiModel: id };
    setForm(updated);
    await saveSettings(updated);
  }

  async function handleSave() {
    await saveSettings(form);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  async function handleTestSheet() {
    if (!sheetUrl.trim()) { Alert.alert('Required', 'Paste your Apps Script URL first.'); return; }
    setSheetLoading(true); setSheetStatus(null);
    const result = await testConnection(sheetUrl.trim());
    setSheetLoading(false);
    if (result.ok) {
      await setSheetsUrl(sheetUrl.trim());
      setSheetStatus('ok');
      setSheetMsg(`Connected to "${result.sheetName || 'HP Parts'}"`);
    } else {
      setSheetStatus('error');
      setSheetMsg(result.error || 'Connection failed');
    }
  }

  async function handleResetUsage() {
    Alert.alert('Reset Usage Stats', 'Clear all cost tracking data?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Reset', style: 'destructive', onPress: async () => { await resetUsage(); setUsage({}); } },
    ]);
  }

  const totalCost  = Object.values(usage).reduce((sum, u) => sum + (Number(u?.cost) || 0), 0);
  const totalCalls = Object.values(usage).reduce((sum, u) => sum + (Number(u?.calls) || 0), 0);

  return (
    <ScrollView style={s.screen} contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
      <Text style={s.pageTitle}>Settings</Text>

      {/* Organization */}
      <View style={s.card}>
        <SectionHeader icon="business" title="ORGANIZATION" />
        <Text style={s.staticLabel}>COMPANY / DIVISION</Text>
        <View style={s.staticBox}><Text style={s.staticTxt}>Hemmersbach — EPMD US FS West 5</Text></View>
        <Text style={s.label}>TECHNICIAN NAME</Text>
        <TextInput style={s.input} value={form.techName} onChangeText={v => set('techName', v)} placeholder="Your name" placeholderTextColor={C.muted} />
        <Text style={s.label}>LOCATION / OFFICE</Text>
        <TextInput style={s.input} value={form.location} onChangeText={v => set('location', v)} placeholder="e.g. Anchorage, AK" placeholderTextColor={C.muted} />
      </View>

      {/* AI Model selector */}
      <View style={s.card}>
        <SectionHeader icon="hardware-chip" title="AI MODEL" color="#C57BFF" />
        <Text style={s.hint}>Tap a model to select it — saves instantly. Each model needs its own API key.</Text>

        {MODEL_ORDER.map(id => {
          const m      = AI_MODELS[id];
          const active = form.aiModel === id;
          const p      = PRICING[id];
          return (
            <TouchableOpacity
              key={id}
              style={[s.modelCard, active && { borderColor: m.color, backgroundColor: '#1A1230' }]}
              onPress={() => selectModel(id)}
              activeOpacity={0.8}
            >
              <View style={[s.modelDot, { backgroundColor: m.color }]} />
              <View style={{ flex: 1 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                  <Text style={[s.modelName, active && { color: m.color }]}>{m.label}</Text>
                  {m.badge && (
                    <View style={[s.badge, { backgroundColor: m.color + '30', borderColor: m.color }]}>
                      <Text style={[s.badgeTxt, { color: m.color }]}>{m.badge}</Text>
                    </View>
                  )}
                </View>
                <Text style={s.modelProvider}>{m.provider}</Text>
                {m.note && <Text style={s.modelNote}>{m.note}</Text>}
              </View>
              <View style={{ alignItems: 'flex-end' }}>
                {id === 'vision'
                  ? <><Text style={[s.modelPrice, { color: m.color }]}>$0 first 1K/mo</Text><Text style={s.modelPrice}>$0.0015/call after</Text></>
                  : <><Text style={s.modelPrice}>${p.input}/M in</Text><Text style={s.modelPrice}>${p.output}/M out</Text></>}
              </View>
              {active && <Ionicons name="checkmark-circle" size={20} color={m.color} style={{ marginLeft: 8 }} />}
            </TouchableOpacity>
          );
        })}
        <Text style={s.pricingNote}>★ Pricing as of Feb 25, 2026 · Per 1 million tokens</Text>
      </View>

      {/* API Keys */}
      <View style={s.card}>
        <SectionHeader icon="key" title="API KEYS" color={C.warning} />

        {[
          { key: 'visionKey', label: 'GOOGLE CLOUD VISION KEY', placeholder: 'AIza... (Cloud Vision API key)', hint: 'vision', special: true },
          { key: 'geminiKey', label: 'GOOGLE GEMINI KEY',       placeholder: 'AIza...',                          hint: 'gemini, vision (parse step)' },
          { key: 'openaiKey', label: 'OPENAI (GPT-4o MINI) KEY',placeholder: 'sk-...',                           hint: 'gpt' },
          { key: 'claudeKey', label: 'ANTHROPIC (CLAUDE) KEY',  placeholder: 'sk-ant-...',                       hint: 'claude' },
        ].map(({ key, label, placeholder, hint, special }) => (
          <View key={key} style={[special && s.visionKeyBox, { marginBottom: 14 }]}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 }}>
              {special && <Ionicons name="eye" size={14} color="#FFB800" />}
              <Text style={[s.label, special && { color: '#FFB800', marginBottom: 0 }]}>{label}</Text>
              {special && (
                <View style={[s.badge, { backgroundColor: '#FFB80030', borderColor: '#FFB800' }]}>
                  <Text style={[s.badgeTxt, { color: '#FFB800' }]}>FREE TIER</Text>
                </View>
              )}
            </View>
            <Text style={s.keyHint}>Used by: {hint}</Text>
            <View style={s.inputRow}>
              <TextInput
                style={[s.input, { flex: 1, marginBottom: 0 }]}
                value={form[key]}
                onChangeText={v => set(key, v)}
                placeholder={placeholder}
                placeholderTextColor={C.muted}
                secureTextEntry={!showKeys[key.replace('Key', '')]}
                autoCapitalize="none"
              />
              <TouchableOpacity onPress={() => setShowKeys(k => ({ ...k, [key.replace('Key', '')]: !k[key.replace('Key', '')] }))} style={s.eyeBtn}>
                <Ionicons name={showKeys[key.replace('Key', '')] ? 'eye-off' : 'eye'} size={18} color={C.muted} />
              </TouchableOpacity>
            </View>
          </View>
        ))}

        <TouchableOpacity style={s.saveBtn} onPress={handleSave}>
          <Ionicons name={saved ? 'checkmark-circle' : 'save'} size={18} color="#fff" />
          <Text style={s.saveBtnTxt}>{saved ? 'Saved!' : 'Save API Keys'}</Text>
        </TouchableOpacity>
      </View>

      {/* Cost calculator */}
      <View style={s.card}>
        <SectionHeader icon="calculator" title="COST CALCULATOR" color={C.success} />
        <View style={s.costSummary}>
          <View style={s.costBox}>
            <Text style={s.costBig}>{totalCalls}</Text>
            <Text style={s.costLbl}>Total API Calls</Text>
          </View>
          <View style={[s.costBox, { borderColor: C.success }]}>
            <Text style={[s.costBig, { color: C.success }]}>{formatCost(totalCost)}</Text>
            <Text style={s.costLbl}>Total Spent</Text>
          </View>
        </View>

        {MODEL_ORDER.map(id => {
          const m       = AI_MODELS[id];
          const raw     = usage[id] || {};
          const calls   = Number(raw.calls        || 0);
          const inTok   = Number(raw.inputTokens  || 0);
          const outTok  = Number(raw.outputTokens || 0);
          const cost    = Number(raw.cost         || 0);
          const p       = PRICING[id];
          return (
            <View key={id} style={[s.costRow, { borderLeftColor: m.color }]}>
              <View style={{ flex: 1 }}>
                <Text style={[s.costModel, { color: m.color }]}>{m.label}</Text>
                <Text style={s.costDetail}>{calls} calls · {(inTok / 1000).toFixed(1)}K in · {(outTok / 1000).toFixed(1)}K out</Text>
                <Text style={s.costRate}>${p.input}/M input · ${p.output}/M output</Text>
              </View>
              <Text style={s.costAmt}>{formatCost(cost)}</Text>
            </View>
          );
        })}

        {/* Rate comparison */}
        <View style={s.rateTable}>
          <Text style={s.rateTitle}>📊 Rate Comparison — Feb 25, 2026</Text>
          <View style={s.rateHeaderRow}>
            <Text style={[s.rateCell, s.rateHeader, { flex: 2 }]}>Model</Text>
            <Text style={[s.rateCell, s.rateHeader]}>Input/1M</Text>
            <Text style={[s.rateCell, s.rateHeader]}>Output/1M</Text>
            <Text style={[s.rateCell, s.rateHeader]}>vs Claude</Text>
          </View>
          {[
            { name: 'Vision+Gemini',    i: 0.00, o: 0.0015, color: '#FFB800', special: 'FREE 1K/mo' },
            { name: 'Gemini Flash Lite',i: 0.08, o: 0.30,   color: '#4A9EFF' },
            { name: 'GPT-4o Mini',      i: 0.15, o: 0.60,   color: '#34D399' },
            { name: 'Claude Haiku 4.5', i: 1.00, o: 5.00,   color: '#C57BFF' },
          ].map(r => {
            const pct = Math.round((1 - (r.i + r.o) / 6.00) * 100);
            return (
              <View key={r.name} style={s.rateRow}>
                <Text style={[s.rateCell, { flex: 2, color: r.color }]}>{r.name}</Text>
                <Text style={[s.rateCell, { color: r.special ? r.color : C.text }]}>{r.special || `$${r.i}`}</Text>
                <Text style={s.rateCell}>{r.special ? '$0.0015/scan' : `$${r.o}`}</Text>
                <Text style={[s.rateCell, { color: pct > 0 ? C.success : C.muted }]}>{pct > 99 ? '~99%' : pct > 0 ? `-${pct}%` : 'base'}</Text>
              </View>
            );
          })}
        </View>

        <TouchableOpacity style={s.resetBtn} onPress={handleResetUsage}>
          <Ionicons name="refresh" size={14} color={C.muted} />
          <Text style={s.resetTxt}>Reset Usage Stats</Text>
        </TouchableOpacity>
      </View>

      {/* Google Sheets */}
      <View style={s.card}>
        <SectionHeader icon="logo-google" title="GOOGLE SHEETS SYNC" color={C.success} />
        <Text style={s.hint}>Paste your Apps Script Web App URL. Both PC and mobile app read/write the same sheet.</Text>
        <Text style={s.label}>APPS SCRIPT WEB APP URL</Text>
        <TextInput
          style={[s.input, { marginBottom: 10 }]}
          value={sheetUrl}
          onChangeText={setSheetUrlState}
          placeholder="https://script.google.com/macros/s/.../exec"
          placeholderTextColor={C.muted}
          autoCapitalize="none"
          autoCorrect={false}
        />
        {sheetStatus && (
          <View style={[s.sheetStatus, { borderColor: sheetStatus === 'ok' ? C.success : C.danger }]}>
            <Ionicons name={sheetStatus === 'ok' ? 'checkmark-circle' : 'close-circle'} size={14}
              color={sheetStatus === 'ok' ? C.success : C.danger} />
            <Text style={[s.sheetStatusTxt, { color: sheetStatus === 'ok' ? C.success : C.danger }]}>{sheetMsg}</Text>
          </View>
        )}
        <TouchableOpacity style={s.sheetTestBtn} onPress={handleTestSheet} disabled={sheetLoading}>
          {sheetLoading
            ? <ActivityIndicator size="small" color="#fff" />
            : <Ionicons name="wifi" size={16} color="#fff" />}
          <Text style={s.sheetTestTxt}>{sheetLoading ? 'Testing...' : 'Test Connection'}</Text>
        </TouchableOpacity>

        <View style={s.howTo}>
          <Text style={s.howToTitle}>HOW TO SET UP</Text>
          {[
            'Open script.google.com → New Project',
            'Paste the Apps Script code (see README)',
            'Deploy → New Deployment → Web App → Anyone can access',
            'Copy the /exec URL and paste above',
          ].map((step, i) => (
            <Text key={i} style={s.howToStep}>{i + 1}. {step}</Text>
          ))}
        </View>
      </View>

      {/* HP Resources */}
      <View style={s.card}>
        <SectionHeader icon="link" title="HP RESOURCES" color={C.muted} />
        {[
          { label: 'HP PartSurfer',  url: 'https://partsurfer.hp.com' },
          { label: 'HP Support',     url: 'https://support.hp.com' },
          { label: 'HP Parts Store', url: 'https://parts.hp.com' },
        ].map(r => (
          <TouchableOpacity key={r.label} style={s.linkRow} onPress={() => Linking.openURL(r.url)}>
            <Ionicons name="globe" size={16} color={C.muted} />
            <Text style={s.linkTxt}>{r.label}</Text>
            <Ionicons name="chevron-forward" size={14} color={C.muted} />
          </TouchableOpacity>
        ))}
      </View>

      {/* How it works */}
      <View style={s.card}>
        <SectionHeader icon="settings" title="HOW IT WORKS" color={C.muted} />
        {[
          'Take a photo of any HP printer part label or packaging',
          'AI reads the label — extracts part number, serial, type, color',
          'AI searches HP PartSurfer for full specs and compatible printers',
          'Set quantity, review, and save to inventory',
          'Export as CSV, PDF, or sync to Google Sheets',
        ].map((step, i) => (
          <View key={i} style={s.stepRow}>
            <View style={s.stepNum}><Text style={s.stepNumTxt}>{i + 1}</Text></View>
            <Text style={s.stepTxt}>{step}</Text>
          </View>
        ))}
      </View>

      <Text style={s.footer}>HP Parts Inventory · GIT Service · Anchorage, AK · {partCount} parts stored</Text>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  screen:     { flex: 1, backgroundColor: C.bg },
  pageTitle:  { fontSize: 26, fontWeight: '800', color: C.text, marginBottom: 16 },
  card:       { backgroundColor: C.card, borderRadius: 16, borderWidth: 1, borderColor: C.border, padding: 16, marginBottom: 14 },
  secHeader:  { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 14 },
  secTitle:   { fontSize: 11, fontWeight: '700', letterSpacing: 1.2 },
  label:      { fontSize: 11, color: C.muted, fontWeight: '600', letterSpacing: 0.8, marginBottom: 6 },
  staticLabel:{ fontSize: 11, color: C.muted, fontWeight: '600', letterSpacing: 0.8, marginBottom: 6 },
  staticBox:  { backgroundColor: C.surface, borderRadius: 10, borderWidth: 1, borderColor: C.border, padding: 12, marginBottom: 12 },
  staticTxt:  { color: C.text, fontSize: 14 },
  hint:       { fontSize: 13, color: C.muted, lineHeight: 18, marginBottom: 12 },
  input:      { backgroundColor: C.surface, borderRadius: 10, borderWidth: 1, borderColor: C.border, color: C.text, fontSize: 14, padding: 12, marginBottom: 12 },
  inputRow:   { flexDirection: 'row', alignItems: 'center', gap: 4 },
  eyeBtn:     { padding: 12 },
  keyHint:    { fontSize: 10, color: C.muted, marginBottom: 6, lineHeight: 15 },
  visionKeyBox:{ backgroundColor: '#1A1500', borderRadius: 12, borderWidth: 1, borderColor: '#FFB80050', padding: 12 },

  modelCard:    { flexDirection: 'row', alignItems: 'center', borderRadius: 12, borderWidth: 1.5, borderColor: C.border, padding: 12, marginBottom: 8, gap: 10 },
  modelDot:     { width: 10, height: 10, borderRadius: 5 },
  modelName:    { fontSize: 14, fontWeight: '700', color: C.text },
  modelProvider:{ fontSize: 11, color: C.muted, marginTop: 2 },
  modelNote:    { fontSize: 10, color: C.muted, marginTop: 2 },
  modelPrice:   { fontSize: 11, color: C.muted },
  pricingNote:  { fontSize: 11, color: C.muted, textAlign: 'center', marginTop: 8 },
  badge:        { borderRadius: 4, borderWidth: 1, paddingHorizontal: 5, paddingVertical: 1 },
  badgeTxt:     { fontSize: 9, fontWeight: '800', letterSpacing: 0.5 },

  saveBtn:    { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: C.accent, borderRadius: 12, padding: 14, gap: 8, marginTop: 4 },
  saveBtnTxt: { color: '#fff', fontWeight: '700', fontSize: 15 },

  costSummary: { flexDirection: 'row', gap: 10, marginBottom: 14 },
  costBox:     { flex: 1, backgroundColor: C.surface, borderRadius: 10, borderWidth: 1, borderColor: C.border, padding: 12, alignItems: 'center' },
  costBig:     { fontSize: 22, fontWeight: '800', color: C.text },
  costLbl:     { fontSize: 11, color: C.muted, marginTop: 2 },
  costRow:     { flexDirection: 'row', alignItems: 'center', borderLeftWidth: 3, paddingLeft: 12, marginBottom: 12, borderRadius: 2 },
  costModel:   { fontSize: 13, fontWeight: '700', marginBottom: 2 },
  costDetail:  { fontSize: 11, color: C.muted },
  costRate:    { fontSize: 10, color: C.muted, marginTop: 1 },
  costAmt:     { fontSize: 16, fontWeight: '800', color: C.text },

  rateTable:    { backgroundColor: C.surface, borderRadius: 10, borderWidth: 1, borderColor: C.border, padding: 12, marginTop: 8 },
  rateTitle:    { fontSize: 12, fontWeight: '700', color: C.text, marginBottom: 10 },
  rateHeaderRow:{ flexDirection: 'row', marginBottom: 6 },
  rateRow:      { flexDirection: 'row', paddingVertical: 5, borderTopWidth: 1, borderTopColor: C.border },
  rateHeader:   { fontSize: 10, color: C.muted, fontWeight: '700' },
  rateCell:     { flex: 1, fontSize: 11, color: C.text },
  resetBtn:     { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, padding: 10, marginTop: 8 },
  resetTxt:     { fontSize: 12, color: C.muted },

  sheetStatus:   { flexDirection: 'row', alignItems: 'center', gap: 6, borderWidth: 1, borderRadius: 8, padding: 8, marginBottom: 10 },
  sheetStatusTxt:{ fontSize: 12, flex: 1 },
  sheetTestBtn:  { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: '#1E3A5C', borderRadius: 10, padding: 13, marginBottom: 14 },
  sheetTestTxt:  { color: '#fff', fontWeight: '700', fontSize: 14 },
  howTo:         { backgroundColor: C.surface, borderRadius: 10, padding: 12 },
  howToTitle:    { fontSize: 10, color: C.muted, fontWeight: '700', letterSpacing: 1, marginBottom: 8 },
  howToStep:     { fontSize: 12, color: C.muted, lineHeight: 20 },

  linkRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: C.border },
  linkTxt: { flex: 1, color: C.text, fontSize: 14 },

  stepRow:    { flexDirection: 'row', alignItems: 'flex-start', gap: 12, marginBottom: 10 },
  stepNum:    { width: 24, height: 24, borderRadius: 12, backgroundColor: C.accent, alignItems: 'center', justifyContent: 'center' },
  stepNumTxt: { color: '#fff', fontSize: 12, fontWeight: '700' },
  stepTxt:    { flex: 1, color: C.muted, fontSize: 13, lineHeight: 18 },
  footer:     { textAlign: 'center', color: C.muted, fontSize: 12, marginTop: 8 },
});
