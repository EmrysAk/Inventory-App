// app/export.jsx — Export & Google Sheets Sync

import { useState, useEffect } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  Alert, ActivityIndicator, ScrollView, TextInput,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { loadParts, loadSettings, updatePart, getSheetsUrl, setSheetsUrl } from '../src/services/db';
import { testConnection, pushAll, pullAll } from '../src/services/sheets';
import { shareCSV, shareJSON, sharePDF } from '../src/services/exportSvc';
import { C, PC_SUPPLY_TYPES } from '../src/constants';

export default function ExportScreen() {
  const [loading,     setLoading]     = useState(false);
  const [loadingId,   setLoadingId]   = useState(null);
  const [parts,       setParts]       = useState([]);
  const [settings,    setSettings]    = useState({});
  const [scriptUrl,   setScriptUrlSt] = useState('');
  const [showInput,   setShowInput]   = useState(false);
  const [urlInput,    setUrlInput]    = useState('');
  const [gsStatus,    setGsStatus]    = useState('');

  useEffect(() => {
    loadParts().then(setParts);
    loadSettings().then(setSettings);
    getSheetsUrl().then(url => { if (url) { setScriptUrlSt(url); setUrlInput(url); } });
  }, []);

  const pcParts      = parts.filter(p => PC_SUPPLY_TYPES.has(p.partType));
  const printerParts = parts.filter(p => !PC_SUPPLY_TYPES.has(p.partType));
  const totalUnits   = parts.reduce((s, p) => s + p.quantity, 0);

  async function run(id, fn) {
    if (!parts.length) { Alert.alert('No Data', 'Scan some parts first.'); return; }
    setLoading(true); setLoadingId(id);
    try { await fn(); }
    catch (e) { Alert.alert('Export Error', e.message); }
    setLoading(false); setLoadingId(null);
  }

  async function saveScriptUrl() {
    const url = urlInput.trim();
    if (!url.startsWith('https://script.google.com')) {
      Alert.alert('Invalid URL', 'Must be a Google Apps Script /exec URL'); return;
    }
    setLoading(true); setLoadingId('gs-test');
    const result = await testConnection(url);
    setLoading(false); setLoadingId(null);
    if (result.ok) {
      await setSheetsUrl(url);
      setScriptUrlSt(url);
      setShowInput(false);
      setGsStatus(`✅ Connected to "${result.sheetName}"`);
    } else {
      Alert.alert('Connection Failed', result.error + '\n\nMake sure the script is deployed as "Anyone can access".');
    }
  }

  async function doGSheetsPush() {
    if (!scriptUrl) { setShowInput(true); return; }
    if (!parts.length) { Alert.alert('No Data', 'Scan some parts first.'); return; }
    setLoading(true); setLoadingId('gs-push');
    try {
      const result = await pushAll(parts);
      setGsStatus(`✅ Pushed ${result.updated || parts.length} parts — ${new Date().toLocaleTimeString()}`);
      Alert.alert('Synced!', `${result.updated || parts.length} parts pushed to Google Sheets.`);
    } catch (e) {
      setGsStatus(`❌ ${e.message}`);
      Alert.alert('Sync Failed', e.message);
    }
    setLoading(false); setLoadingId(null);
  }

  async function doGSheetsPull() {
    if (!scriptUrl) { setShowInput(true); return; }
    setLoading(true); setLoadingId('gs-pull');
    try {
      const sheetParts = await pullAll();
      const local      = await loadParts();
      const localMap   = {};
      local.forEach(p => { if (p.partNumber) localMap[p.partNumber.toUpperCase()] = p; });
      for (const sp of sheetParts) {
        const key = (sp.partNumber || '').toUpperCase();
        if (key && localMap[key]) await updatePart(localMap[key].id, { ...sp, id: localMap[key].id });
      }
      const fresh = await loadParts();
      setParts(fresh);
      setGsStatus(`✅ Pulled ${sheetParts.length} parts — ${new Date().toLocaleTimeString()}`);
      Alert.alert('Synced!', `${sheetParts.length} parts pulled from Google Sheets.`);
    } catch (e) {
      setGsStatus(`❌ ${e.message}`);
      Alert.alert('Sync Failed', e.message);
    }
    setLoading(false); setLoadingId(null);
  }

  function ExportCard({ id, icon, iconBg, iconColor, title, desc, onPress }) {
    return (
      <TouchableOpacity style={s.expCard} onPress={onPress} disabled={loading}>
        <View style={[s.expIcon, { backgroundColor: iconBg }]}>
          {loading && loadingId === id
            ? <ActivityIndicator size="small" color={iconColor} />
            : <Ionicons name={icon} size={22} color={iconColor} />}
        </View>
        <View style={{ flex: 1 }}>
          <Text style={s.expTitle}>{title}</Text>
          <Text style={s.expDesc}>{desc}</Text>
        </View>
        <Ionicons name="chevron-forward" size={18} color={C.muted} />
      </TouchableOpacity>
    );
  }

  const gsLoading = loading && ['gs-push', 'gs-pull', 'gs-test'].includes(loadingId);

  return (
    <View style={s.container}>
      <ScrollView contentContainerStyle={s.scroll}>

        {/* Summary */}
        <View style={s.summaryCard}>
          <Text style={s.summaryTitle}>Inventory Summary</Text>
          <View style={s.summaryRow}>
            <View style={s.sumItem}><Text style={[s.sumNum, { color: C.accent }]}>{parts.length}</Text><Text style={s.sumLbl}>Types</Text></View>
            <View style={s.sumDivider} />
            <View style={s.sumItem}><Text style={[s.sumNum, { color: '#A78BFA' }]}>{pcParts.length}</Text><Text style={s.sumLbl}>PC Parts</Text></View>
            <View style={s.sumDivider} />
            <View style={s.sumItem}><Text style={[s.sumNum, { color: '#FB923C' }]}>{printerParts.length}</Text><Text style={s.sumLbl}>Printer HW</Text></View>
            <View style={s.sumDivider} />
            <View style={s.sumItem}><Text style={[s.sumNum, { color: C.success }]}>{totalUnits}</Text><Text style={s.sumLbl}>Units</Text></View>
          </View>
        </View>

        {/* Google Sheets */}
        <Text style={s.sectionLabel}>☁️ GOOGLE SHEETS SYNC</Text>
        <View style={s.gsCard}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 10 }}>
            <View style={[s.expIcon, { backgroundColor: '#0a3d1f' }]}>
              {gsLoading
                ? <ActivityIndicator size="small" color={C.success} />
                : <Ionicons name="logo-google" size={22} color={C.success} />}
            </View>
            <View style={{ flex: 1 }}>
              <Text style={s.expTitle}>Google Sheets</Text>
              <Text style={[s.expDesc,
                gsStatus.startsWith('✅') && { color: C.success },
                gsStatus.startsWith('❌') && { color: C.danger }]}>
                {gsStatus || (scriptUrl ? 'Ready to sync' : 'Tap ⚙ to configure')}
              </Text>
            </View>
            <TouchableOpacity onPress={() => setShowInput(!showInput)} style={{ padding: 4 }}>
              <Ionicons name="settings-outline" size={18} color={C.muted} />
            </TouchableOpacity>
          </View>

          {showInput && (
            <View style={{ gap: 8, marginBottom: 10 }}>
              <Text style={{ color: C.muted, fontSize: 11 }}>APPS SCRIPT WEB APP URL</Text>
              <TextInput
                style={s.urlInput}
                value={urlInput}
                onChangeText={setUrlInput}
                placeholder="https://script.google.com/macros/s/…/exec"
                placeholderTextColor={C.muted}
                autoCapitalize="none"
                autoCorrect={false}
              />
              <TouchableOpacity style={s.testBtn} onPress={saveScriptUrl} disabled={loading}>
                <Text style={s.testBtnTxt}>Test & Save URL</Text>
              </TouchableOpacity>
            </View>
          )}

          <View style={{ flexDirection: 'row', gap: 8 }}>
            <TouchableOpacity style={[s.syncBtn, { flex: 1 }]} onPress={doGSheetsPush} disabled={loading}>
              <Ionicons name="cloud-upload-outline" size={15} color={C.success} />
              <Text style={[s.syncBtnTxt, { color: C.success }]}>Push to Sheet</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[s.syncBtn, { flex: 1 }]} onPress={doGSheetsPull} disabled={loading}>
              <Ionicons name="cloud-download-outline" size={15} color={C.success} />
              <Text style={[s.syncBtnTxt, { color: C.success }]}>Pull from Sheet</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* By category */}
        <Text style={[s.sectionLabel, { marginTop: 18 }]}>📊 EXPORT BY CATEGORY</Text>
        <ExportCard id="csv-pc"      icon="hardware-chip-outline" iconBg="#1a1a3a" iconColor="#A78BFA"
          title="PC Parts (Supplies) CSV"
          desc={`Toner, drums, fusers, kits — ${pcParts.length} types`}
          onPress={() => run('csv-pc', () => shareCSV(pcParts, 'HP_PC_Parts'))} />
        <ExportCard id="csv-hw"      icon="construct-outline"     iconBg="#2a1a0a" iconColor="#FB923C"
          title="Printer Hardware CSV"
          desc={`Boards, trays, assemblies — ${printerParts.length} types`}
          onPress={() => run('csv-hw', () => shareCSV(printerParts, 'HP_Printer_Hardware'))} />

        <Text style={[s.sectionLabel, { marginTop: 18 }]}>📄 FULL EXPORTS</Text>
        <ExportCard id="csv-all" icon="grid-outline"          iconBg="#1A3A1A" iconColor={C.success}
          title="All Parts — CSV" desc="Complete inventory, all categories."
          onPress={() => run('csv-all', () => shareCSV(parts, 'HP_Parts_All'))} />
        <ExportCard id="pdf"     icon="document-text-outline" iconBg="#2D1515" iconColor={C.danger}
          title="PDF Report" desc="HP-branded report with summary and full list."
          onPress={() => run('pdf', () => sharePDF(parts, settings))} />
        <ExportCard id="json"    icon="code-slash-outline"    iconBg="#2D2A1A" iconColor={C.warning}
          title="JSON Backup" desc="For PC app import or offline backup."
          onPress={() => run('json', () => shareJSON(parts))} />

      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  container:    { flex: 1, backgroundColor: C.bg },
  scroll:       { padding: 16, paddingBottom: 48 },
  summaryCard:  { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 14, padding: 20, marginBottom: 20 },
  summaryTitle: { fontSize: 11, color: C.muted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 14 },
  summaryRow:   { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around' },
  sumItem:      { alignItems: 'center' },
  sumNum:       { fontSize: 24, fontWeight: '900', letterSpacing: -1 },
  sumLbl:       { fontSize: 10, color: C.muted, marginTop: 2 },
  sumDivider:   { width: 1, height: 36, backgroundColor: C.border },
  sectionLabel: { fontSize: 11, color: C.muted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 10 },
  expCard:      { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 14, padding: 16, marginBottom: 8 },
  expIcon:      { width: 44, height: 44, borderRadius: 11, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  expTitle:     { fontSize: 14, fontWeight: '700', color: C.text, marginBottom: 2 },
  expDesc:      { fontSize: 12, color: C.muted, lineHeight: 18 },
  gsCard:       { backgroundColor: C.card, borderWidth: 1, borderColor: '#0f4a2a', borderRadius: 14, padding: 16, marginBottom: 8 },
  urlInput:     { backgroundColor: '#0D1929', borderWidth: 1, borderColor: C.border, borderRadius: 8, padding: 10, color: C.text, fontSize: 11, fontFamily: 'monospace' },
  testBtn:      { backgroundColor: C.accent + '22', borderWidth: 1, borderColor: C.accent + '44', borderRadius: 8, padding: 10, alignItems: 'center' },
  testBtnTxt:   { color: C.accent, fontSize: 13, fontWeight: '600' },
  syncBtn:      { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: '#0a3d1f', borderRadius: 10, padding: 10 },
  syncBtnTxt:   { fontSize: 13, fontWeight: '600' },
});
