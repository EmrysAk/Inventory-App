// app/item/[id].jsx — Part Detail

import { useState, useEffect } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  TextInput, Alert, Image, Linking,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { getPartById, updatePart, updateQuantity, deletePart } from '../../src/services/db';
import { C, CONDITIONS } from '../../src/constants';

function InfoRow({ label, value, valueStyle }) {
  if (!value || value === 'null') return null;
  return (
    <View style={s.infoRow}>
      <Text style={s.infoLabel}>{label}</Text>
      <Text style={[s.infoValue, valueStyle]}>{value}</Text>
    </View>
  );
}

export default function PartDetail() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const [item,    setItem]    = useState(null);
  const [editing, setEditing] = useState(false);
  const [form,    setForm]    = useState({ notes: '', location: '', condition: 'Unknown' });

  useEffect(() => { load(); }, [id]);

  async function load() {
    const found = await getPartById(id);
    if (found) {
      setItem(found);
      setForm({ notes: found.notes || '', location: found.location || '', condition: found.condition || 'Unknown' });
    }
  }

  async function saveEdits() {
    await updatePart(id, form);
    setEditing(false);
    load();
  }

  async function adjustQty(delta) {
    if (!item) return;
    const newQty = Math.max(0, item.quantity + delta);
    await updateQuantity(id, newQty);
    setItem(prev => ({ ...prev, quantity: newQty }));
  }

  async function handleDelete() {
    Alert.alert('Remove Part', 'Delete this part from inventory?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => {
        await deletePart(id);
        router.back();
      }},
    ]);
  }

  if (!item) return null;

  return (
    <View style={s.container}>
      <ScrollView contentContainerStyle={s.scroll}>

        {/* Hero */}
        <View style={s.hero}>
          <Text style={s.heroPN}>{item.partNumber || 'No Part #'}</Text>
          <Text style={s.heroDesc}>{item.hpDescription || item.description || 'No description'}</Text>
          <View style={s.qtyHero}>
            <TouchableOpacity style={s.qtyBtn} onPress={() => adjustQty(-1)}>
              <Ionicons name="remove" size={24} color={item.quantity === 0 ? C.muted : C.text} />
            </TouchableOpacity>
            <View style={s.qtyMid}>
              <Text style={[s.qtyNum, item.quantity === 0 && { color: C.danger }]}>{item.quantity}</Text>
              <Text style={s.qtyLbl}>IN STOCK</Text>
            </View>
            <TouchableOpacity style={s.qtyBtn} onPress={() => adjustQty(1)}>
              <Ionicons name="add" size={24} color={C.text} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Photo */}
        {item.imageUri && (
          <Image source={{ uri: item.imageUri }} style={s.photo} resizeMode="contain" />
        )}

        {/* HP PartSurfer */}
        {(item.hpDescription || item.availability || item.partSurferNotes) && (
          <View style={s.section}>
            <Text style={s.sectionTitle}>🌐 HP PartSurfer Info</Text>
            <InfoRow label="Description" value={item.hpDescription} />
            <InfoRow label="Availability" value={item.availability}
              valueStyle={item.availability === 'Discontinued' ? { color: C.danger } : { color: C.success }} />
            {item.replacementPartNumber && (
              <InfoRow label="Replacement Part #" value={item.replacementPartNumber}
                valueStyle={{ color: C.warning, fontFamily: 'monospace' }} />
            )}
            {item.partSurferNotes && <InfoRow label="Notes" value={item.partSurferNotes} />}
          </View>
        )}

        {/* Part details */}
        <View style={s.section}>
          <Text style={s.sectionTitle}>📊 Part Details</Text>
          <InfoRow label="Part Type"    value={item.partType} />
          <InfoRow label="Color"        value={item.color} />
          <InfoRow label="Page Yield"   value={item.pageYield} />
          <InfoRow label="Condition"    value={item.condition} />
          <InfoRow label="Date Added"   value={new Date(item.createdAt).toLocaleString()} />
          <InfoRow label="Last Updated" value={new Date(item.lastSeenAt).toLocaleString()} />
        </View>

        {/* Serial numbers */}
        {item.serialNumbers?.length > 0 && (
          <View style={s.section}>
            <Text style={s.sectionTitle}>🔢 Serial Numbers</Text>
            {item.serialNumbers.map((sn, i) => (
              <View key={i} style={s.snRow}>
                <Ionicons name="barcode-outline" size={16} color={C.muted} />
                <Text style={s.snText}>{sn}</Text>
              </View>
            ))}
          </View>
        )}

        {/* Compatible printers */}
        {item.compatiblePrinters?.length > 0 && (
          <View style={s.section}>
            <Text style={s.sectionTitle}>✓ Compatible HP Printers</Text>
            <View style={s.chipRow}>
              {item.compatiblePrinters.map((p, i) => (
                <View key={i} style={s.chip}><Text style={s.chipTxt}>{p}</Text></View>
              ))}
            </View>
          </View>
        )}

        {/* Location & notes (editable) */}
        <View style={s.section}>
          <View style={s.sectionHeader}>
            <Text style={s.sectionTitle}>📝 Location & Notes</Text>
            {!editing
              ? <TouchableOpacity onPress={() => setEditing(true)}><Text style={s.editBtn}>Edit</Text></TouchableOpacity>
              : <TouchableOpacity onPress={saveEdits}><Text style={[s.editBtn, { color: C.success }]}>Save</Text></TouchableOpacity>}
          </View>

          <Text style={s.fieldLbl}>Storage Location / Bin</Text>
          {editing
            ? <TextInput style={s.input} value={form.location} onChangeText={v => setForm(f => ({ ...f, location: v }))} placeholder="e.g. Shelf B2, Box 3" placeholderTextColor={C.muted} />
            : <Text style={s.fieldVal}>{item.location || '—'}</Text>}

          <Text style={s.fieldLbl}>Condition</Text>
          {editing ? (
            <View style={s.condRow}>
              {CONDITIONS.map(c => (
                <TouchableOpacity key={c} style={[s.condChip, form.condition === c && s.condChipOn]}
                  onPress={() => setForm(f => ({ ...f, condition: c }))}>
                  <Text style={[s.condTxt, form.condition === c && s.condTxtOn]}>{c}</Text>
                </TouchableOpacity>
              ))}
            </View>
          ) : <Text style={s.fieldVal}>{item.condition || '—'}</Text>}

          <Text style={s.fieldLbl}>Notes</Text>
          {editing
            ? <TextInput style={[s.input, { height: 90, textAlignVertical: 'top' }]} value={form.notes} onChangeText={v => setForm(f => ({ ...f, notes: v }))} placeholder="Any notes about this part..." placeholderTextColor={C.muted} multiline numberOfLines={4} />
            : <Text style={s.fieldVal}>{item.notes || '—'}</Text>}
        </View>

        {/* Delete */}
        <TouchableOpacity style={s.deleteBtn} onPress={handleDelete}>
          <Ionicons name="trash-outline" size={16} color={C.danger} />
          <Text style={s.deleteTxt}>Remove from Inventory</Text>
        </TouchableOpacity>

      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  scroll:    { padding: 16, paddingBottom: 40 },

  hero:     { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 16, padding: 20, marginBottom: 14 },
  heroPN:   { fontSize: 22, fontWeight: '900', color: C.accent, letterSpacing: -0.5, marginBottom: 6 },
  heroDesc: { fontSize: 13, color: C.text, lineHeight: 20, opacity: 0.85, marginBottom: 18 },

  qtyHero: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 16 },
  qtyBtn:  { width: 48, height: 48, borderRadius: 14, backgroundColor: C.border, alignItems: 'center', justifyContent: 'center' },
  qtyMid:  { alignItems: 'center', minWidth: 80 },
  qtyNum:  { fontSize: 48, fontWeight: '900', color: C.accent, lineHeight: 52 },
  qtyLbl:  { fontSize: 10, color: C.muted, textTransform: 'uppercase', letterSpacing: 1 },

  photo:   { width: '100%', height: 200, borderRadius: 12, marginBottom: 14, backgroundColor: C.card },

  section:      { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 14, padding: 16, marginBottom: 14 },
  sectionTitle: { fontSize: 14, fontWeight: '800', color: C.text, marginBottom: 12 },
  sectionHeader:{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  editBtn:      { color: C.accent, fontWeight: '700', fontSize: 14 },

  infoRow:   { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: C.border },
  infoLabel: { fontSize: 12, color: C.muted, flex: 1 },
  infoValue: { fontSize: 13, color: C.text, fontWeight: '500', flex: 2, textAlign: 'right' },

  snRow:  { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: C.border },
  snText: { fontFamily: 'monospace', fontSize: 13, color: C.text },

  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  chip:    { backgroundColor: C.bg, borderWidth: 1, borderColor: C.border, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 4 },
  chipTxt: { fontSize: 11, color: C.success },

  fieldLbl: { fontSize: 10, color: C.muted, textTransform: 'uppercase', letterSpacing: 0.5, marginTop: 12, marginBottom: 5 },
  fieldVal: { fontSize: 14, color: C.text, paddingVertical: 4 },
  input:    { backgroundColor: C.bg, borderWidth: 1, borderColor: C.border, borderRadius: 9, padding: 11, color: C.text, fontSize: 14 },

  condRow:    { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 4 },
  condChip:   { borderWidth: 1, borderColor: C.border, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6, backgroundColor: C.bg },
  condChipOn: { backgroundColor: C.accent, borderColor: C.accent },
  condTxt:    { fontSize: 12, color: C.muted },
  condTxtOn:  { color: '#fff', fontWeight: '700' },

  deleteBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 14, borderRadius: 12, borderWidth: 1, borderColor: C.danger, backgroundColor: C.card },
  deleteTxt: { color: C.danger, fontWeight: '600' },
});
