// app/index.jsx — HP Parts Inventory Dashboard

import { useState, useCallback } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  TextInput, Alert, RefreshControl, Pressable, ScrollView,
} from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { loadParts, updateQuantity, deletePart } from '../src/services/db';
import { C, typeColor, FILTERS } from '../src/constants';

// ── Stat card ─────────────────────────────────────────────────────────────────

function StatCard({ num, label, color }) {
  return (
    <View style={[s.statCard, { borderTopColor: color }]}>
      <Text style={[s.statNum, { color }]}>{num}</Text>
      <Text style={s.statLabel}>{label}</Text>
    </View>
  );
}

// ── Qty controls ──────────────────────────────────────────────────────────────

function QtyControl({ qty, onDec, onInc }) {
  return (
    <View style={s.qtyRow}>
      <TouchableOpacity style={s.qtyBtn} onPress={onDec}>
        <Ionicons name="remove" size={16} color={qty === 0 ? C.muted : C.text} />
      </TouchableOpacity>
      <View style={[s.qtyBox, qty === 0 && s.qtyBoxZero]}>
        <Text style={[s.qtyNum, qty === 0 && s.qtyNumZero]}>{qty}</Text>
      </View>
      <TouchableOpacity style={s.qtyBtn} onPress={onInc}>
        <Ionicons name="add" size={16} color={C.text} />
      </TouchableOpacity>
    </View>
  );
}

// ── Part card ─────────────────────────────────────────────────────────────────

function PartCard({ item, onPress, onQtyChange, onDelete }) {
  const tc          = typeColor(item.partType);
  const outOfStock  = item.quantity === 0;

  return (
    <Pressable
      style={({ pressed }) => [s.card, pressed && s.cardPressed, outOfStock && s.cardZero]}
      onPress={onPress}
      onLongPress={() => onDelete(item.id)}
    >
      <View style={[s.cardBar, { backgroundColor: tc }]} />
      <View style={s.cardBody}>

        {/* Top row: type pill, color dot, out-of-stock badge */}
        <View style={s.cardTop}>
          <View style={[s.typePill, { borderColor: tc }]}>
            <Text style={[s.typePillText, { color: tc }]}>{item.partType || 'Other'}</Text>
          </View>
          {item.color && item.color !== 'null' && (
            <View style={s.colorDot}>
              <Text style={s.colorDotText}>{item.color.charAt(0)}</Text>
            </View>
          )}
          {outOfStock && (
            <View style={s.outPill}><Text style={s.outPillText}>OUT OF STOCK</Text></View>
          )}
        </View>

        <Text style={s.partNum}>{item.partNumber || 'No Part #'}</Text>
        <Text style={s.desc} numberOfLines={2}>
          {item.hpDescription || item.description || 'No description'}
        </Text>

        {item.compatiblePrinters?.length > 0 && (
          <Text style={s.compat} numberOfLines={1}>
            <Text style={{ color: C.success }}>✓ </Text>
            {item.compatiblePrinters.slice(0, 2).join(' · ')}
            {item.compatiblePrinters.length > 2 ? ` +${item.compatiblePrinters.length - 2}` : ''}
          </Text>
        )}

        {item.serialNumbers?.length > 0 && (
          <Text style={s.serial}>
            S/N: {item.serialNumbers.slice(0, 2).join(', ')}
            {item.serialNumbers.length > 2 ? ` +${item.serialNumbers.length - 2}` : ''}
          </Text>
        )}

        <View style={s.cardBottom}>
          <Text style={s.cardDate}>{new Date(item.lastSeenAt).toLocaleDateString()}</Text>
          <QtyControl
            qty={item.quantity}
            onDec={() => onQtyChange(item.id, item.quantity - 1)}
            onInc={() => onQtyChange(item.id, item.quantity + 1)}
          />
        </View>
      </View>
    </Pressable>
  );
}

// ── Main screen ───────────────────────────────────────────────────────────────

export default function InventoryScreen() {
  const [parts,        setParts]        = useState([]);
  const [filtered,     setFiltered]     = useState([]);
  const [search,       setSearch]       = useState('');
  const [activeFilter, setActiveFilter] = useState('All');
  const [refreshing,   setRefreshing]   = useState(false);
  const router = useRouter();

  const load = useCallback(async () => {
    const data = await loadParts();
    setParts(data);
    apply(data, search, activeFilter);
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  function apply(data, q, f) {
    let out = data;
    if (f !== 'All') {
      out = out.filter(p => {
        if (f === 'Other') {
          return !['Toner Cartridge','Ink Cartridge','Fuser Assembly','Drum Unit','Maintenance Kit','Roller Kit'].includes(p.partType);
        }
        return p.partType === f || (f === 'Toner Cartridge' && p.partType === 'Ink Cartridge');
      });
    }
    if (q.trim()) {
      const lq = q.toLowerCase();
      out = out.filter(p =>
        p.partNumber?.toLowerCase().includes(lq) ||
        p.description?.toLowerCase().includes(lq) ||
        p.hpDescription?.toLowerCase().includes(lq) ||
        (p.serialNumbers || []).some(sn => sn.toLowerCase().includes(lq)) ||
        (p.compatiblePrinters || []).some(m => m.toLowerCase().includes(lq))
      );
    }
    setFiltered(out);
  }

  function onSearch(text) { setSearch(text);   apply(parts, text, activeFilter); }
  function onFilter(f)    { setActiveFilter(f); apply(parts, search, f); }

  async function handleQty(id, newQty) {
    if (newQty < 0) return;
    await updateQuantity(id, newQty);
    const updated = parts.map(p => p.id === id ? { ...p, quantity: newQty } : p);
    setParts(updated);
    apply(updated, search, activeFilter);
  }

  async function handleDelete(id) {
    Alert.alert('Remove Part', 'Delete this part from inventory?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => {
        await deletePart(id);
        load();
      }},
    ]);
  }

  async function onRefresh() {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  }

  const totalUnits = parts.reduce((sum, p) => sum + p.quantity, 0);
  const outOfStock = parts.filter(p => p.quantity === 0).length;
  const lowStock   = parts.filter(p => p.quantity > 0 && p.quantity <= 2).length;

  return (
    <View style={s.container}>

      {/* Stats */}
      <View style={s.statsRow}>
        <StatCard num={parts.length} label="Part Types"   color={C.accent}   />
        <StatCard num={totalUnits}   label="Total Units"  color={C.success}  />
        <StatCard num={lowStock}     label="Low Stock"    color={C.warning}  />
        <StatCard num={outOfStock}   label="Out of Stock" color={C.danger}   />
      </View>

      {/* Search + action buttons */}
      <View style={s.searchRow}>
        <View style={s.searchBox}>
          <Ionicons name="search" size={15} color={C.muted} />
          <TextInput
            style={s.searchInput}
            placeholder="Part #, serial, printer model..."
            placeholderTextColor={C.muted}
            value={search}
            onChangeText={onSearch}
          />
          {search.length > 0 && (
            <TouchableOpacity onPress={() => onSearch('')}>
              <Ionicons name="close-circle" size={16} color={C.muted} />
            </TouchableOpacity>
          )}
        </View>
        <TouchableOpacity style={s.iconBtn} onPress={() => router.push('/export')}>
          <Ionicons name="share-outline" size={20} color={C.accent} />
        </TouchableOpacity>
        <TouchableOpacity style={s.iconBtn} onPress={() => router.push('/pcsync')}>
          <Ionicons name="desktop-outline" size={20} color={C.accent} />
        </TouchableOpacity>
        <TouchableOpacity style={s.iconBtn} onPress={() => router.push('/settings')}>
          <Ionicons name="settings-outline" size={20} color={C.muted} />
        </TouchableOpacity>
      </View>

      {/* Filter chips */}
      <FlatList
        horizontal
        data={FILTERS}
        keyExtractor={f => f}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={s.filterRow}
        renderItem={({ item: f }) => (
          <TouchableOpacity
            style={[s.chip, activeFilter === f && s.chipActive]}
            onPress={() => onFilter(f)}
          >
            <Text style={[s.chipText, activeFilter === f && s.chipTextActive]}>{f}</Text>
          </TouchableOpacity>
        )}
      />

      {/* Parts list */}
      <FlatList
        data={filtered}
        keyExtractor={p => p.id}
        contentContainerStyle={filtered.length === 0 ? s.emptyWrap : { padding: 12, paddingBottom: 120 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={C.accent} />}
        renderItem={({ item }) => (
          <PartCard
            item={item}
            onPress={() => router.push(`/item/${item.id}`)}
            onQtyChange={handleQty}
            onDelete={handleDelete}
          />
        )}
        ListEmptyComponent={
          <View style={s.empty}>
            <Ionicons name="print-outline" size={72} color={C.border} />
            <Text style={s.emptyTitle}>No Parts Yet</Text>
            <Text style={s.emptySub}>Tap SCAN PART to add your first item</Text>
          </View>
        }
      />

      {/* FAB */}
      <TouchableOpacity style={s.fab} onPress={() => router.push('/scan')} activeOpacity={0.85}>
        <Ionicons name="camera" size={22} color="#fff" />
        <Text style={s.fabText}>SCAN PART</Text>
      </TouchableOpacity>
    </View>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────

const s = StyleSheet.create({
  container:  { flex: 1, backgroundColor: C.bg },

  statsRow:   { flexDirection: 'row', paddingHorizontal: 12, paddingTop: 12, gap: 8 },
  statCard:   { flex: 1, backgroundColor: C.card, borderRadius: 10, borderTopWidth: 2, padding: 10, alignItems: 'center' },
  statNum:    { fontSize: 20, fontWeight: '800', letterSpacing: -0.5 },
  statLabel:  { fontSize: 9.5, color: C.muted, marginTop: 2, textAlign: 'center', textTransform: 'uppercase', letterSpacing: 0.5 },

  searchRow:  { flexDirection: 'row', padding: 12, gap: 8, alignItems: 'center' },
  searchBox:  { flex: 1, flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10, gap: 8 },
  searchInput:{ flex: 1, color: C.text, fontSize: 14 },
  iconBtn:    { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 10, padding: 10 },

  filterRow:  { paddingHorizontal: 12, paddingBottom: 8, gap: 8 },
  chip:       { paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20, backgroundColor: C.card, borderWidth: 1, borderColor: C.border },
  chipActive: { backgroundColor: C.accentDim, borderColor: C.accent },
  chipText:   { fontSize: 12, color: C.muted, fontWeight: '600' },
  chipTextActive: { color: C.accent },

  card:        { flexDirection: 'row', backgroundColor: C.card, borderRadius: 14, marginBottom: 10, borderWidth: 1, borderColor: C.border, overflow: 'hidden' },
  cardPressed: { opacity: 0.75 },
  cardZero:    { opacity: 0.55 },
  cardBar:     { width: 4 },
  cardBody:    { flex: 1, padding: 14 },
  cardTop:     { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 6 },

  typePill:     { borderWidth: 1.5, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 2 },
  typePillText: { fontSize: 10, fontWeight: '700', letterSpacing: 0.5 },
  colorDot:     { width: 18, height: 18, borderRadius: 9, backgroundColor: C.border, alignItems: 'center', justifyContent: 'center' },
  colorDotText: { fontSize: 10, color: C.text, fontWeight: '700' },
  outPill:      { backgroundColor: '#3B0F0F', borderRadius: 4, paddingHorizontal: 6, paddingVertical: 2 },
  outPillText:  { fontSize: 9, color: C.danger, fontWeight: '700', letterSpacing: 0.5 },

  partNum:  { fontSize: 16, fontWeight: '800', color: C.accent, letterSpacing: -0.3, marginBottom: 3 },
  desc:     { fontSize: 12.5, color: C.text, lineHeight: 18, opacity: 0.85, marginBottom: 4 },
  compat:   { fontSize: 11, color: C.muted, marginBottom: 3 },
  serial:   { fontSize: 11, color: C.muted, fontFamily: 'monospace' },

  cardBottom: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 10 },
  cardDate:   { fontSize: 11, color: C.muted },

  qtyRow:    { flexDirection: 'row', alignItems: 'center', gap: 6 },
  qtyBtn:    { width: 28, height: 28, borderRadius: 8, backgroundColor: C.border, alignItems: 'center', justifyContent: 'center' },
  qtyBox:    { minWidth: 36, paddingHorizontal: 8, height: 28, borderRadius: 8, backgroundColor: C.accentDim, alignItems: 'center', justifyContent: 'center' },
  qtyBoxZero:{ backgroundColor: '#2D1515' },
  qtyNum:    { fontSize: 15, fontWeight: '800', color: C.accent },
  qtyNumZero:{ color: C.danger },

  emptyWrap: { flex: 1 },
  empty:     { paddingTop: 80, alignItems: 'center', gap: 10 },
  emptyTitle:{ fontSize: 20, fontWeight: '700', color: C.muted },
  emptySub:  { fontSize: 13, color: C.muted, opacity: 0.7 },

  fab:     { position: 'absolute', bottom: 24, alignSelf: 'center', flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.accent, paddingHorizontal: 30, paddingVertical: 16, borderRadius: 50, elevation: 10, shadowColor: C.accent, shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.5, shadowRadius: 14 },
  fabText: { color: '#fff', fontWeight: '800', fontSize: 14, letterSpacing: 1 },
});
